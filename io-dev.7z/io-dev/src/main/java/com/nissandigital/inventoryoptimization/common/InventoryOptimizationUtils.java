package com.nissandigital.inventoryoptimization.common;

import java.sql.Timestamp;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.nissandigital.inventoryoptimization.dto.Status;
import com.nissandigital.inventoryoptimization.exception.NoDataFoundException;

/**
 * Contains utility methods used across parts details
 * 
 * @author Nissan Digital
 *
 */
public class InventoryOptimizationUtils {
	
	/**
	 * Creates Response status with message
	 * 
	 * @param message
	 * @return Status
	 */
	public static Status setMessage(String message) {
		Status status = new Status();
		status.setMessage(message);
		return status;
	}

	/**
	 * Generate the current UTC Timestamp
	 * 
	 * @return Timestamp
	 */
	public static Timestamp getCurrentUTCTimestamp() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS ");
		ZonedDateTime utcZoned = ZonedDateTime.now(ZoneOffset.UTC);
		return Timestamp.valueOf(formatter.format(utcZoned));
	}

	

	
}
