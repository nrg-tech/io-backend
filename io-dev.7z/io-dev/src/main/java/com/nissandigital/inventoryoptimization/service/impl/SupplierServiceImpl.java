package com.nissandigital.inventoryoptimization.service.impl;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nissandigital.inventoryoptimization.dto.SupplierDTO;
import com.nissandigital.inventoryoptimization.repository.SupplierRepository;
import com.nissandigital.inventoryoptimization.service.SupplierService;

@Service
public class SupplierServiceImpl implements SupplierService {

	@Autowired
	SupplierRepository supplierRepository;

	@Autowired
	ModelMapper modelMapper;

	@Override
	public List<SupplierDTO> findAllSuppliers() {
		return StreamSupport.stream(supplierRepository.findAll().spliterator(), false)
				.map(w -> modelMapper.map(w, SupplierDTO.class)).collect(Collectors.toList());
	}

}
