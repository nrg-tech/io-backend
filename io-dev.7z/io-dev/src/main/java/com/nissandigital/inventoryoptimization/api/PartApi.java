package com.nissandigital.inventoryoptimization.api;

import java.util.List;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nissandigital.inventoryoptimization.dto.InventoryOptimizationError;
import com.nissandigital.inventoryoptimization.dto.PartDTO;
import com.nissandigital.inventoryoptimization.dto.Status;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * Api specifications for part resource
 * 
 * @author Nissan Digital
 *
 */
@RequestMapping(value = "parts")
public interface PartApi {
	
 
    @ApiOperation(value = "Find part by part id", nickname = "getPartById", notes = "Returns a part based on part id", response = PartDTO.class, tags={"Part"})
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "Part details successfully fetched with part id", response = PartDTO.class),
        @ApiResponse(code = 422, message = "Invalid part id supplied",response = InventoryOptimizationError.class),
        @ApiResponse(code = 404, message = "Part not found",response = InventoryOptimizationError.class) })
    @GetMapping(value = "/{partId}",
        produces = { "application/json" })
    ResponseEntity<PartDTO> getPartById(@ApiParam(value = "Part id of part to return",required=true) @PathVariable("partId") int partId);

    
    
    @ApiOperation(value = "Returns all active parts", nickname = "getAllParts", notes = "Returns all active certifications", response = PartDTO.class, responseContainer = "List", tags={"Part"})
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "List of all active parts", response = PartDTO.class, responseContainer = "List")})
    @GetMapping(
        produces = { "application/json" })
    ResponseEntity<List<PartDTO>> getAllParts();
	
    
    
    @ApiOperation(value = "Add a new part to inventory optimization", nickname = "addPart", notes = "", tags={ "Part" })
    @ApiResponses(value = { 
    	@ApiResponse(code = 201, message = "Part details successfully added", response = Status.class),
    	@ApiResponse(code = 400, message = "Unable to add part", response = InventoryOptimizationError.class),
        @ApiResponse(code = 422, message = "Invalid input",response = InventoryOptimizationError.class) })
    @PostMapping(
        produces = { "application/json" }, 
        consumes = { "application/json" })
    ResponseEntity<Status> addPart(@ApiParam(value = "Part object that needs to be added to inventory optimization" ,required=true )  @Valid @RequestBody PartDTO body);

    
    
    @ApiOperation(value = "Update an existing part", nickname = "updatePart", notes = "", tags={ "Part"})
    @ApiResponses(value = { 
    	@ApiResponse(code = 200, message = "Part details successfully updated", response = Status.class),
        @ApiResponse(code = 404, message = "Part not found",response = InventoryOptimizationError.class),
        @ApiResponse(code = 422, message = "Invalid part id supplied",response = InventoryOptimizationError.class)})
    @PutMapping(
        produces = { "application/json" }, 
        consumes = { "application/json" })
    ResponseEntity<Status> updatePart(@ApiParam(value = "Part details that needs to be updated in inventory optimization" ,required=true )  @Valid @RequestBody PartDTO body);
    
    
    
    @ApiOperation(value = "Deletes a certification", nickname = "deletePart", notes = "Updates a part as inactive", tags={ "Part"})
    @ApiResponses(value = { 
    	@ApiResponse(code = 200, message = "Part details deleted successfully", response = Status.class),
        @ApiResponse(code = 404, message = "Part not found",response = InventoryOptimizationError.class) })
    @DeleteMapping(value = "/{partId}",
        produces = { "application/json" })
    ResponseEntity<Status> deletePart(@ApiParam(value = "Part id of part to be deleted",required=true) @PathVariable("partId") int partId);

}
