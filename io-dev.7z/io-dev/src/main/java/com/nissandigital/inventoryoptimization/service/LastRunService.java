package com.nissandigital.inventoryoptimization.service;

import java.util.List;

import com.nissandigital.inventoryoptimization.dto.LastRunDTO;

/**
 * @author Nissan Digital
 *
 */

public interface LastRunService {

	/**
	 * Fetch last run details filtered by given service level
	 * 
	 * @return
	 */
	public List<LastRunDTO> findLastRunDetailsByServiceLevel(double serviceLevel);

}
