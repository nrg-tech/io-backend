package com.nissandigital.inventoryoptimization.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.nissandigital.inventoryoptimization.entity.PartCategoryEntity;


public interface PartCategoryRepository extends CrudRepository<PartCategoryEntity, Long> {
	
	@Query(value = "SELECT idpm.partId FROM PartEntity idpm LEFT JOIN PartCategoryMappingEntity ipc ON idpm.partId=ipc.partCategoryMappingIdentity.skPartId WHERE ipc.partCategoryMappingIdentity.skPartId is NULL")
	List<Long> findUnmappedParts();

    List<PartCategoryEntity> findAll();


}
