package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

@Embeddable
public class SupplierPartsIdentity implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@NotNull
	@Column(name = "SK_PART_ID")
	private long partId;

	@NotNull
	@Column(name = "SK_SUPLR_ID")
	private long supplierId;

	public long getPartId() {
		return partId;
	}

	public void setPartId(long partId) {
		this.partId = partId;
	}

	public long getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(long supplierId) {
		this.supplierId = supplierId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public SupplierPartsIdentity() {
	}

}
