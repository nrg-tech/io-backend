package com.nissandigital.inventoryoptimization.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.nissandigital.inventoryoptimization.api.TopPartsStatisticsApi;
import com.nissandigital.inventoryoptimization.dto.DemandVariabilityContributionDTO;
import com.nissandigital.inventoryoptimization.dto.SupplyVariabilityContributionDTO;
import com.nissandigital.inventoryoptimization.dto.TopPartsStatisticsOverviewDTO;
import com.nissandigital.inventoryoptimization.service.TopPartsStatisticsService;

import io.swagger.annotations.Api;

/**
 * Controller which handles the Top Parts statistical details
 * 
 * @author Nissan Digital
 *
 */
@RestController
@Api(tags = "Top-parts statistics")
public class TopPartsStatisticsController implements TopPartsStatisticsApi {

	@Autowired
	TopPartsStatisticsService topPartsStatisticsService;

	@Override
	public ResponseEntity<List<DemandVariabilityContributionDTO>> getDemandVariabilityContribution() {
		return new ResponseEntity<>(topPartsStatisticsService.getDemandVariabilityContribution(), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<SupplyVariabilityContributionDTO>> getSupplyVariabilityContribution() {
		return new ResponseEntity<>(topPartsStatisticsService.getSupplyVariabilityContribution(), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<TopPartsStatisticsOverviewDTO>> getTopPartsOverview() {
		return new ResponseEntity<>(topPartsStatisticsService.getTopPartsOverviewDto(), HttpStatus.OK);
	}

}
