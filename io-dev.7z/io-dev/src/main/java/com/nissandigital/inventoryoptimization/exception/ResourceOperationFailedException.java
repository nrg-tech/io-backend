//package com.nissandigital.inventoryoptimization.exception;
//
//public class ResourceOperationFailedException extends RuntimeException {
//
//	private static final long serialVersionUID = -3744711306336536875L;
//
//	public ResourceOperationFailedException() {
//		super();
//	}
//
//	public ResourceOperationFailedException(String msg) {
//		super(msg);
//	}
//}