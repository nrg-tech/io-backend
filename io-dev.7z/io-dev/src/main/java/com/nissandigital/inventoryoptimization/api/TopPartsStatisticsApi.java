package com.nissandigital.inventoryoptimization.api;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nissandigital.inventoryoptimization.dto.DemandVariabilityContributionDTO;
import com.nissandigital.inventoryoptimization.dto.InventoryOptimizationError;
import com.nissandigital.inventoryoptimization.dto.SupplyVariabilityContributionDTO;
import com.nissandigital.inventoryoptimization.dto.TopPartsStatisticsOverviewDTO;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RequestMapping("top-parts-statistics")
public interface TopPartsStatisticsApi {

	@ApiOperation(value = "Fetches top parts overview information", nickname = "getTopPartsOverview", notes = "Returns the top parts overview information", response = TopPartsStatisticsOverviewDTO.class, tags = "Top-parts statistics")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Statistics overview information successfully fetched for current user's plant", response = TopPartsStatisticsOverviewDTO.class),
			@ApiResponse(code = 404, message = "Statistical information not found for current user's plant", response = InventoryOptimizationError.class) })
	@GetMapping(value = "/overview", produces = { "application/json" })
	ResponseEntity<List<TopPartsStatisticsOverviewDTO>> getTopPartsOverview();

	@ApiOperation(value = "Fetches information for demand variability contribution", nickname = "getDemandVariabilityContribution", notes = "Returns the demand variability contribution", response = DemandVariabilityContributionDTO.class, tags = "Top-parts statistics")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Demand variability contribution successfully fetched for current user's plant", response = DemandVariabilityContributionDTO.class),
			@ApiResponse(code = 404, message = "Demand variability contribution not found for current user's plant", response = InventoryOptimizationError.class) })
	@GetMapping(value = "/demand-variability-contribution", produces = { "application/json" })
	ResponseEntity<List<DemandVariabilityContributionDTO>> getDemandVariabilityContribution();

	@ApiOperation(value = "Fetches information for Supply variability contribution", nickname = "getSupplyVariabilityContribution", notes = "Returns the supply variability contribution", response = SupplyVariabilityContributionDTO.class, tags = "Top-parts statistics")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Supply variability contribution successfully fetched for current user's plant", response = SupplyVariabilityContributionDTO.class),
			@ApiResponse(code = 404, message = "Supply variability contribution not found for current user's plant", response = InventoryOptimizationError.class) })
	@GetMapping(value = "/supply-variability-contribution", produces = { "application/json" })
	ResponseEntity<List<SupplyVariabilityContributionDTO>> getSupplyVariabilityContribution();
}
