package com.nissandigital.inventoryoptimization.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.nissandigital.inventoryoptimization.entity.UserEntity;

/**
 * Repository class for performing database operations on user entity
 * 
 * @author Nissan Digital
 *
 */
@Repository
public interface UserRepository extends CrudRepository<UserEntity, Long> {

	@Query(value = "select io.* from io_stat_model.io_user \r\n" + 
			" AS io JOIN io_stat_model.io_user_role_master AS iom ON io.user_role_id = iom.user_role_id AND iom.user_role_desc = ?1", nativeQuery = true)
	public List<UserEntity> findByUserRole(String userRoleDescription);

}
