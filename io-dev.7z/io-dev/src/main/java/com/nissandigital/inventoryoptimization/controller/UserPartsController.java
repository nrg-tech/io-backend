package com.nissandigital.inventoryoptimization.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.nissandigital.inventoryoptimization.api.UserPartsApi;
import com.nissandigital.inventoryoptimization.common.InventoryOptimizationUtils;
import com.nissandigital.inventoryoptimization.dto.Status;
import com.nissandigital.inventoryoptimization.dto.UserPartsDTO;
import com.nissandigital.inventoryoptimization.service.UserPartsService;

import io.swagger.annotations.Api;

/**
 * Controller which handles the userParts mapping
 * 
 * @author Nissan Digital
 *
 */
@RestController
@Api(value = "UserParts")
public class UserPartsController implements UserPartsApi {

	private static Logger LOGGER = LoggerFactory.getLogger(PartController.class);

	@Autowired
	UserPartsService userPartsService;

	public ResponseEntity<Status> addPartsToPartsController(@Valid UserPartsDTO userPartsDTO) {
		userPartsService.addPartsToPartsController(userPartsDTO);
		String message = String.format("Added parts with specific parts controller of id = ",userPartsDTO.getUserId());
		LOGGER.debug(message);
		return new ResponseEntity<>(InventoryOptimizationUtils.setMessage(message), HttpStatus.OK);
	}

}
