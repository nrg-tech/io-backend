package com.nissandigital.inventoryoptimization.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.nissandigital.inventoryoptimization.api.SupplierApi;
import com.nissandigital.inventoryoptimization.dto.SupplierDTO;
import com.nissandigital.inventoryoptimization.service.SupplierService;

import io.swagger.annotations.Api;

@RestController
@Api(tags ="supplier")
public class SupplierController implements SupplierApi {

	@Autowired
	private SupplierService supplierService;

	@Override
	public ResponseEntity<List<SupplierDTO>> getSuppliers() {
		List<SupplierDTO> supplierDTO = supplierService.findAllSuppliers();
		return new ResponseEntity<>(supplierDTO, HttpStatus.OK);

	}

}
