package com.nissandigital.inventoryoptimization.api;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nissandigital.inventoryoptimization.dto.LastRunDTO;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * Api specification for Last Run Table details
 * 
 * @author Nissan Digital
 *
 */
@RequestMapping(value = "last-run")
public interface LastRunApi {

	@ApiOperation(value = "Returns last run details filtered by given service level", nickname = "getAllLastRunDetails", notes = "Returns last run details filtered by given service level", response = LastRunDTO.class, responseContainer = "List", tags = {
			"LastRun" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Detail of last run details filtered by given service level", response = LastRunDTO.class, responseContainer = "List") })
	@GetMapping(produces = { "application/json" })
	ResponseEntity<List<LastRunDTO>> getLastRunDetailsByServiceLevel(@RequestParam double serviceLevel);

}
