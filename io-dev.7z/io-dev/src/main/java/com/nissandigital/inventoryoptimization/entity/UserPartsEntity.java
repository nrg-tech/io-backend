package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the user parts database table.
 * 
 */
@Entity
@Table(name = "IO_USER_PARTS",schema="io_stat_model")
public class UserPartsEntity implements Serializable {
	
	private static final long serialVersionUID = 1L;


	@EmbeddedId
	private UserPartsIdentity userPartsIdentity;
	
	@Column(name = "CREATED_BY")
	private long createdBy;
	
	@Column(name = "CREATED_DT")
    @Temporal(TemporalType.TIMESTAMP)
	private Date createdDt;
	
	@Column(name = "UPDATED_BY")
	private long 	updatedBy;
	
	@Column(name = "UPDATED_DT")
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedDt;

	public UserPartsIdentity getUserPartsIdentity() {
		return userPartsIdentity;
	}

	public void setUserPartsIdentity(UserPartsIdentity userPartsIdentity) {
		this.userPartsIdentity = userPartsIdentity;
	}

	public long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public long getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(long updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public UserPartsEntity(UserPartsIdentity userPartsIdentity, long createdBy, Date createdDt, long updatedBy,
			Date updatedDt) {
		super();
		this.userPartsIdentity = userPartsIdentity;
		this.createdBy = createdBy;
		this.createdDt = createdDt;
		this.updatedBy = updatedBy;
		this.updatedDt = updatedDt;
	}

	public UserPartsEntity() {
		super();
	}

	

	
	
		
}