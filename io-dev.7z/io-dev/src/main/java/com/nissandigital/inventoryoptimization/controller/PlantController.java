package com.nissandigital.inventoryoptimization.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.nissandigital.inventoryoptimization.api.PlantAPI;
import com.nissandigital.inventoryoptimization.dto.PlantDetailsDTO;
import com.nissandigital.inventoryoptimization.service.PlantService;

import io.swagger.annotations.Api;

/**
 * Controller which handles the plant details
 * 
 * @author Rahul Kumar
 *
 */
@RestController
@Api(tags = "plant")
public class PlantController implements PlantAPI {

	@Autowired
	PlantService plantService;

	@Override
	public ResponseEntity<List<PlantDetailsDTO>> getPlantInformation() {
		return new ResponseEntity<>(plantService.getPlantInformation(), HttpStatus.OK);
	}
}
