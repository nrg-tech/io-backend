package com.nissandigital.inventoryoptimization.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.nissandigital.inventoryoptimization.api.PartsCategoryApi;
import com.nissandigital.inventoryoptimization.common.InventoryOptimizationUtils;
import com.nissandigital.inventoryoptimization.dto.CategoryDTO;
import com.nissandigital.inventoryoptimization.dto.PartCategoryDTO;
import com.nissandigital.inventoryoptimization.dto.PartDetailsDTO;
import com.nissandigital.inventoryoptimization.dto.PartsCategoryMappingDTO;
import com.nissandigital.inventoryoptimization.dto.Status;
import com.nissandigital.inventoryoptimization.service.PartCategoryService;
import io.swagger.annotations.Api;

/**
 * Controller which handles the parts to parts category mapping
 * 
 * @author Nissan Digital
 *
 */
@RestController
@Api(value = "PartsCategory")
public class PartCategoryController implements PartsCategoryApi {

	private static Logger LOGGER = LoggerFactory.getLogger(PartCategoryController.class);

	@Autowired
	PartCategoryService partCategoryService;

	@Autowired
	private PartCategoryService categoryService;

	public ResponseEntity<Status> addPartsToPartsCategory(@Valid PartsCategoryMappingDTO partsCategoryMappingDTO) {
		partCategoryService.addPartsToPartsCategory(partsCategoryMappingDTO);
		String message = String.format("Added parts with specific parts category id = ",
				partsCategoryMappingDTO.getCategoryId());
		LOGGER.debug(message);
		return new ResponseEntity<>(InventoryOptimizationUtils.setMessage(message), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Status> addPartsCategory(@Valid PartCategoryDTO partsCategoryDTO) {
		partCategoryService.addPartsCategory(partsCategoryDTO);
		String message = String.format("Added new parts category");
		LOGGER.debug(message);
		return new ResponseEntity<>(InventoryOptimizationUtils.setMessage(message), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<CategoryDTO>> getCategories() {
		List<CategoryDTO> categoryDTOs = categoryService.findAllCategories();
		String message = String.format("Fetched list of part categories");
		LOGGER.debug(message);
		return new ResponseEntity<>(categoryDTOs, HttpStatus.OK);

	}

	@Override
	public ResponseEntity<List<PartDetailsDTO>> getPartsByCategoryId(long categoryId) {
		List<PartDetailsDTO> partsList = partCategoryService.findPartsByCategory(categoryId);
		String message = String.format("Fetched list of part categories for categoryId = ", categoryId);
		LOGGER.debug(message);
		return new ResponseEntity<>(partsList, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<PartDetailsDTO>> getUnmappedParts() {
		List<PartDetailsDTO> partsList = partCategoryService.findUnmappedParts();
		String message = String.format("Fetched list of unmapped parts to any category");
		LOGGER.debug(message);
		return new ResponseEntity<>(partsList, HttpStatus.OK);
	}

}
