package com.nissandigital.inventoryoptimization.entity;

import java.sql.Timestamp;

import javax.persistence.Column;

/**
 * The parent entity class containing common entity fields.
 * 
 */
public abstract class BaseEntity {

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "creation_date")
	private Timestamp creationDate;

	@Column(name = "last_updated_by")
	private String lastUpdatedBy;

	@Column(name = "last_updated_date")
	private Timestamp lastUpdatedDate;

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Timestamp creationDate) {
		this.creationDate = creationDate;
	}

	public String setLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdateDate) {
		this.lastUpdatedDate = lastUpdateDate;
	}

}
