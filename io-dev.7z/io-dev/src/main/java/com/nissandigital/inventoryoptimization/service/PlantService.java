package com.nissandigital.inventoryoptimization.service;

import java.util.List;

import com.nissandigital.inventoryoptimization.dto.PlantDetailsDTO;

/**
 * Service class to handle Plant Information and business logic
 * 
 * @author Nissan Digital
 *
 */
public interface PlantService {

	/**
	 * Fetch a list of plant information that the current user can access
	 * 
	 * @Returns the plant information for the current user
	 */
	List<PlantDetailsDTO> getPlantInformation();
}
