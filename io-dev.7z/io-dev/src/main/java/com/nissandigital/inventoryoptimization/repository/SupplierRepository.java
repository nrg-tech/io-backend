package com.nissandigital.inventoryoptimization.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.nissandigital.inventoryoptimization.entity.SupplierAddressBookEntity;

/**
 * Class to perform database operations on Supplier Address Book Entity
 * 
 * @author Nissan Digital
 *
 */
public interface SupplierRepository extends CrudRepository<SupplierAddressBookEntity, Long> {

	List<SupplierAddressBookEntity> findBySkSupplierIdIn(List<Long> supplierIdList);

}
