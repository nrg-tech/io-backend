package com.nissandigital.inventoryoptimization.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.nissandigital.inventoryoptimization.entity.UserRoleEntity;

public interface UserRoleRepository extends CrudRepository<UserRoleEntity, Long> {

	List<UserRoleEntity> findByUserRoleDesc(String role);
}
