package com.nissandigital.inventoryoptimization.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import com.nissandigital.inventoryoptimization.entity.SupplierPartsEntity;
import com.nissandigital.inventoryoptimization.entity.SupplierPartsIdentity;

public interface SupplierPartsRepository extends CrudRepository<SupplierPartsEntity, SupplierPartsIdentity> {

	@Query(value = "select ips.supplierPartsIdentity.supplierId from SupplierPartsEntity ips where ips.supplierPartsIdentity.partId in (:partIdList)")
	List<Long> findSupplierIdsForPartIds(List<Long> partIdList);
	
	
}
