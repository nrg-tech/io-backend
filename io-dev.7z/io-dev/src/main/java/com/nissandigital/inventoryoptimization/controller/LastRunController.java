package com.nissandigital.inventoryoptimization.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import com.nissandigital.inventoryoptimization.api.LastRunApi;
import com.nissandigital.inventoryoptimization.dto.LastRunDTO;
import com.nissandigital.inventoryoptimization.service.LastRunService;

import io.swagger.annotations.Api;

/**
 * Controller which handle the Last Run Details
 * 
 * @author Nissan Digital
 *
 */
@RestController
@CrossOrigin
@Api(value = "lastRun")
public class LastRunController implements LastRunApi {

	@Autowired
	private LastRunService lastRunService;

	@Override
	public ResponseEntity<List<LastRunDTO>> getLastRunDetailsByServiceLevel(double serviceLevel) {
		return new ResponseEntity<List<LastRunDTO>>(lastRunService.findLastRunDetailsByServiceLevel(serviceLevel), HttpStatus.OK);
	}

}
