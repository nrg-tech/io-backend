package com.nissandigital.inventoryoptimization.configuration;
//package com.nissandigital.inventoryoptimization.configuration;
//
//import java.io.IOException;
//
//import javax.servlet.FilterChain;
//import javax.servlet.ServletException;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import org.eclipse.jetty.http.HttpStatus;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.core.Ordered;
//import org.springframework.core.annotation.Order;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
//import org.springframework.stereotype.Component;
//import org.springframework.web.filter.OncePerRequestFilter;
//
//import com.nissandigital.inventoryoptimization.authentication.dto.InventoryoptimizationUser;
//import com.nissandigital.inventoryoptimization.constants.AuthenticationConstants;
//
//@Component
//@Order(Ordered.HIGHEST_PRECEDENCE)
//public class GDFilter extends OncePerRequestFilter {
//
//	@Autowired
//	@Qualifier("ioUserDetailsService")
//	UserDetailsService userDetailsService;
//	
//	@Value("${server.servlet.contextPath}")
//	private String contextPath;
//
//	@Override
//	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
//			throws ServletException, IOException {
//
//		if (AuthenticationConstants.FILTER_EXCLUDE_PATHS.stream()
//				.anyMatch(excludeUrl -> request.getRequestURL().toString().contains(excludeUrl))) {
//			filterChain.doFilter(request, response);
//		} else if(request.getRequestURL().toString().endsWith(contextPath)) {
//			filterChain.doFilter(request, response);
//		} else {
//			try {
//				String username = request.getHeader(AuthenticationConstants.USER_HEADER);
//				logger.info("Request Headers, key : cn , value : " + username);
//
//				if (username == null) {
//					logger.info("GD Authentication failed for the request");
//					response.setStatus(HttpStatus.UNAUTHORIZED_401);
//				} else {
//					UserDetails userDetails = userDetailsService.loadUserByUsername(username);
//					InventoryoptimizationUser idmsUser = (InventoryoptimizationUser) userDetails;
//
//					UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
//							idmsUser, null, idmsUser.getAuthorities());
//					usernamePasswordAuthenticationToken
//							.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
//					Authentication securityContext = SecurityContextHolder.getContext().getAuthentication();
//
//					if (securityContext == null) {
//						SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
//					}
//					filterChain.doFilter(request, response);
//				}
//			} catch (NullPointerException | UsernameNotFoundException e) {
//				logger.error(e.getMessage());
//				response.setStatus(HttpStatus.UNAUTHORIZED_401);
//			}
//		}
//	}
//}