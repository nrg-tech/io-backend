package com.nissandigital.inventoryoptimization.repository;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import com.nissandigital.inventoryoptimization.entity.PartCategoryMappingEntity;
import com.nissandigital.inventoryoptimization.entity.PartCategoryMappingIdentity;

public interface PartsCategoryMappingRepository extends CrudRepository<PartCategoryMappingEntity, PartCategoryMappingIdentity> {

	@Query(value = "SELECT ipc.partCategoryMappingIdentity.skPartId FROM PartCategoryMappingEntity ipc where ipc.partCategoryMappingIdentity.partCategoryId = :partCategoryId")
	List<Long> findPartsByPartCategoryId(Long partCategoryId);


}
