package com.nissandigital.inventoryoptimization.service.impl;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nissandigital.inventoryoptimization.dto.AggregateStatisticsDTO;
import com.nissandigital.inventoryoptimization.entity.StatisticalMVMetricsEntity;
import com.nissandigital.inventoryoptimization.exception.NoDataFoundException;
import com.nissandigital.inventoryoptimization.repository.StatisticalMVMetricsRepository;
import com.nissandigital.inventoryoptimization.service.AggregateStatisticsService;
import com.nissandigital.inventoryoptimization.service.UserService;

/**
 * Implementation class for aggregate statistics service
 * 
 * @author Nissan Digital
 *
 */
@Service
public class AggregateStatisticsServiceImpl implements AggregateStatisticsService {

	@Autowired
	UserService userService;

	@Autowired
	ModelMapper modelMapper;

	@Autowired
	StatisticalMVMetricsRepository statisticsRepository;

	@Override
	public AggregateStatisticsDTO getAggregateStatistics() {
		Integer plantId = userService.getCurrentUser().getPlantId();
		Optional<StatisticalMVMetricsEntity> statistics = statisticsRepository.findById(plantId);
		if (statistics.isEmpty()) {
			throw new NoDataFoundException("Statistical data for given plant ID '" + plantId + "' cannot be found");
		}
		return modelMapper.map(statistics.get(), AggregateStatisticsDTO.class);
	}

}
