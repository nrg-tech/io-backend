package com.nissandigital.inventoryoptimization.service;

import com.nissandigital.inventoryoptimization.dto.DateTimeDTO;

/**
 * Service class to handle Date-Time Information and business logic
 * 
 * @author Nissan Digital
 *
 */
public interface DateTimeService {

	/**
	 * @Returns the current date and time of the server
	 */
	DateTimeDTO getCurrentDateTime();

	/**
	 * Fetch information regarding the last-run of the process
	 * 
	 * @Returns the information regarding the last-run of the process
	 */
	DateTimeDTO getModelExecutionDate(Integer plantId);
}
