package com.nissandigital.inventoryoptimization.service;

import java.util.List;

import com.nissandigital.inventoryoptimization.dto.SupplierDTO;

public interface SupplierService {
	
	public List<SupplierDTO> findAllSuppliers();

}
