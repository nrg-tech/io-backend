package com.nissandigital.inventoryoptimization.api;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nissandigital.inventoryoptimization.dto.DateTimeDTO;
import com.nissandigital.inventoryoptimization.dto.InventoryOptimizationError;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RequestMapping("timestamp")
public interface DateTimeApi {

	@ApiOperation(value = "Fetch the current date and time", nickname = "getCurrentDateTime", notes = "Returns current date and time", response = DateTimeDTO.class, tags = "dateTime")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Date and Time successfully fetched", response = DateTimeDTO.class),
			@ApiResponse(code = 500, message = "Server date time error", response = InventoryOptimizationError.class) })
	@GetMapping(value = "/current-time", produces = "application/json")
	ResponseEntity<DateTimeDTO> getCurrentDateTime();

	@ApiOperation(value = "Fetch information regarding the last-run of the process for the given plant ID", nickname = "getModelExecutionDate", notes = "Returns information regarding the last-run of the process for the given plant ID", response = DateTimeDTO.class, tags = "dateTime")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Date and time successfully fetched for the given plant ID", response = DateTimeDTO.class),
			@ApiResponse(code = 422, message = "Invalid plant ID", response = InventoryOptimizationError.class),
			@ApiResponse(code = 404, message = "Run-time information for the plant with given plant ID is not found", response = InventoryOptimizationError.class) })
	@GetMapping(value = "/model-execution-date/{plantId}")
	ResponseEntity<DateTimeDTO> getModelExecutionDate(
			@ApiParam(value = "Plant ID", required = true) @PathVariable("plantId") Integer plantId);
}
