package com.nissandigital.inventoryoptimization.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.nissandigital.inventoryoptimization.entity.StatisticalModelOutputViewEntity;
import com.nissandigital.inventoryoptimization.entity.StatisticalModelOutputViewIdentity;

/**
 * Repository class for performing database operations on Statistical Model View
 * Entity
 * 
 * @author Nissan Digital
 *
 */
@Repository
public interface LastRunRepository
		extends CrudRepository<StatisticalModelOutputViewEntity, StatisticalModelOutputViewIdentity> {

	@Query(value = "select * from io_stat_model.io_mv_sm_op_curr where service_level=:serviceLevel", nativeQuery = true)
	List<StatisticalModelOutputViewEntity> findAllByServiceLevel(@Param("serviceLevel") Double serviceLevel);
}
