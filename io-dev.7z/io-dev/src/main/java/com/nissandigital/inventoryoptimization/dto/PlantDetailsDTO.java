package com.nissandigital.inventoryoptimization.dto;

/**
 * DTO class containing plant information
 * 
 * @author Nissan Digital
 *
 */
public class PlantDetailsDTO {
	private Integer plantId;
	private String plantName;

	/**
	 * @return the plantId
	 */
	public Integer getPlantId() {
		return plantId;
	}

	/**
	 * @param plantId the plantId to set
	 */
	public void setPlantId(Integer plantId) {
		this.plantId = plantId;
	}

	/**
	 * @return the plantName
	 */
	public String getPlantName() {
		return plantName;
	}

	/**
	 * @param plantName the plantName to set
	 */
	public void setPlantName(String plantName) {
		this.plantName = plantName;
	}

}
