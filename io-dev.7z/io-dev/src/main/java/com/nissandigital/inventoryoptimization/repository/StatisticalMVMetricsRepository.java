package com.nissandigital.inventoryoptimization.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.nissandigital.inventoryoptimization.entity.StatisticalMVMetricsEntity;

/**
 * Repository class for performing database operations on statistical MV metrics entity
 * 
 * @author Nissan Digital
 *
 */
@Repository
public interface StatisticalMVMetricsRepository extends CrudRepository<StatisticalMVMetricsEntity, Integer>{

}
