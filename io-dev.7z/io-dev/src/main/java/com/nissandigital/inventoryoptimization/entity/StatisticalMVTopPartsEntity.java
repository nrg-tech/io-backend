package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistence class for the io_mv_top_parts database table.
 * 
 * @author Nissan Digital
 * 
 */
@Entity
@Table(name = "io_mv_top_parts")
@NamedQuery(name = "StatisticalMVTopPartsEntity.findAll", query = "SELECT i FROM StatisticalMVTopPartsEntity i")
public class StatisticalMVTopPartsEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "id")
	@Id
	private Integer id;

	@Column(name = "plant_id")
	private Integer plantId;

	@Column(name = "avg_dly_dem")
	private double averageDailyDemand;

	@Column(name = "avg_sup_cycle_time")
	private double averageSupplyCycleTime;

	@Column(name = "cov_var_dly_dem")
	private double coefVariableDailyDemand;

	@Column(name = "cov_var_sup_cycle_time")
	private double coefVariableSupplyCycleTime;

	@Column(name = "current_float")
	private double currentFloat;

	@Column(name = "float_surplus")
	private double floatSurplus;

	@Column(name = "item_number")
	private String itemNumber;

	@Column(name = "recom_float")
	private double recommendedFloat;

	public StatisticalMVTopPartsEntity() {
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the plantId
	 */
	public Integer getPlantId() {
		return plantId;
	}

	/**
	 * @param plantId the plantId to set
	 */
	public void setPlantId(Integer plantId) {
		this.plantId = plantId;
	}

	/**
	 * @return the averageDailyDemand
	 */
	public double getAverageDailyDemand() {
		return averageDailyDemand;
	}

	/**
	 * @param averageDailyDemand the averageDailyDemand to set
	 */
	public void setAverageDailyDemand(double avgDlyDem) {
		this.averageDailyDemand = avgDlyDem;
	}

	/**
	 * @return the averageSupplyCycleTime
	 */
	public double getAverageSupplyCycleTime() {
		return averageSupplyCycleTime;
	}

	/**
	 * @param averageSupplyCycleTime the averageSupplyCycleTime to set
	 */
	public void setAverageSupplyCycleTime(double avgSupCycleTime) {
		this.averageSupplyCycleTime = avgSupCycleTime;
	}

	/**
	 * @return the coefVariableDailyDemand
	 */
	public double getCoefVariableDailyDemand() {
		return coefVariableDailyDemand;
	}

	/**
	 * @param coefVariableDailyDemand the coefVariableDailyDemand to set
	 */
	public void setCoefVariableDailyDemand(double covVarDlyDem) {
		this.coefVariableDailyDemand = covVarDlyDem;
	}

	/**
	 * @return the coefVariableSupplyCycleTime
	 */
	public double getCoefVariableSupplyCycleTime() {
		return coefVariableSupplyCycleTime;
	}

	/**
	 * @param coefVariableSupplyCycleTime the coefVariableSupplyCycleTime to set
	 */
	public void setCoefVariableSupplyCycleTime(double covVarSupCycleTime) {
		this.coefVariableSupplyCycleTime = covVarSupCycleTime;
	}

	/**
	 * @return the currentFloat
	 */
	public double getCurrentFloat() {
		return currentFloat;
	}

	/**
	 * @param currentFloat the currentFloat to set
	 */
	public void setCurrentFloat(double currentFloat) {
		this.currentFloat = currentFloat;
	}

	/**
	 * @return the floatSurplus
	 */
	public double getFloatSurplus() {
		return floatSurplus;
	}

	/**
	 * @param floatSurplus the floatSurplus to set
	 */
	public void setFloatSurplus(double floatSurplus) {
		this.floatSurplus = floatSurplus;
	}

	/**
	 * @return the itemNumber
	 */
	public String getItemNumber() {
		return itemNumber;
	}

	/**
	 * @param itemNumber the itemNumber to set
	 */
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	/**
	 * @return the recommendedFloat
	 */
	public double getRecommendedFloat() {
		return recommendedFloat;
	}

	/**
	 * @param recommendedFloat the recommendedFloat to set
	 */
	public void setRecommendedFloat(double recomFloat) {
		this.recommendedFloat = recomFloat;
	}

}