package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 * Class for Statistical Model View Entity
 * 
 * @author Nissan Digital
 *
 */
@Entity
@Table(name = "io_mv_sm_op_curr", schema = "io_stat_model")
@IdClass(StatisticalModelOutputViewIdentity.class)
public class StatisticalModelOutputViewEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "plant_cd", length = 2)
	private String plantCode;

	@Id
	@Column(name = "item_num", length = 30)
	private String itemNumber;

	@Id
	@Column(name = "service_level", precision = 15)
	private Double serviceLevel;

	@Column(name = "model_exec_dt", length = 29)
	private Date modelExecutionDate;

	@Column(name = "unit_price", precision = 15)
	private Double unitPrice;

	@Column(name = "suplr_type", length = 15)
	private String supplierType;

	@Column(name = "suplr_code", length = 15)
	private String supplierCode;

	@Column(name = "bsl_inv_qty", precision = 15)
	private Double baselineInventoryQuantity;

	@Column(name = "bsl_inv_val", precision = 15)
	private Double baselineInventoryValue;

	@Column(name = "abc_cls_inv_val", length = 1)
	private Character abcClassInventoryValue;

	@Column(name = "abc_class_consump_val", length = 1)
	private Character abcClassConsumptionValue;

	@Column(name = "xyz_class_cov_dem_frcst", length = 1)
	private Character xyzClassCoefficientOfVarianceDemandForecast;

	@Column(name = "min_ran_ordr_qty", precision = 15)
	private Double minimumRanOrderQuantity;

	@Column(name = "snp_qty", precision = 15)
	private Double snqQuantity;

	@Column(name = "float_recom_days", precision = 15)
	private Double floatRecommendedDays;

	@Column(name = "oprtnl_rsrv_qty", precision = 15)
	private Double operationalReserveQuantity;

	@Column(name = "oprtnl_rsrv_val", precision = 15)
	private Double operationalReserveValue;

	@Column(name = "dir_pipeline_stock_qty", precision = 15)
	private Double directPipelineStockQuantity;

	@Column(name = "ilc_pipeline_stock_qty", precision = 15)
	private Double ilcPipelineStockQuantity;

	@Column(name = "scrap_per_tot_ann_dem", precision = 15)
	private Double scrapPercentageToAnnualDemand;

	@Column(name = "cycle_loss_per_tot_ann_dem", precision = 15)
	private Double cycleLossPercentageTotalAnnualDemand;

	@Column(name = "tot_recom_float_hrs", precision = 15)
	private Double totalRecommendedFloatHours;

	@Column(name = "tot_recom_float_days", precision = 15)
	private Double totalRecommendedFloatDays;

	@Column(name = "float_inv_savings", precision = 15)
	private Double floatInventorySavings;

	@Column(name = "min_recom_float_hrs", precision = 15)
	private Double minimumRecommendedFloatHours;

	@Column(name = "min_recom_float_days", precision = 15)
	private Double minimumRecommendedFloatDays;

	@Column(name = "min_float_qty", precision = 15)
	private Double minimumFloatQuantity;

	@Column(name = "chg_per_recom_float_val", precision = 15)
	private Double changePerRecommendedFloatValue;

	@Column(name = "part_category_desc")
	private String partsCategory;

	@Column(name = "parts_controller", length = 50)
	private String partsController;

	@Column(name = "part_type_cd")
	private String partTypeCode;

	/**
	 * @return the partTypeCode
	 */
	public String getPartTypeCode() {
		return partTypeCode;
	}

	/**
	 * @param partTypeCode the partTypeCode to set
	 */
	public void setPartTypeCode(String partTypeCode) {
		this.partTypeCode = partTypeCode;
	}

	/**
	 * @return the plantCode
	 */
	public String getPlantCode() {
		return plantCode;
	}

	/**
	 * @param plantCode the plantCode to set
	 */
	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}

	/**
	 * @return the itemNumber
	 */
	public String getItemNumber() {
		return itemNumber;
	}

	/**
	 * @param itemNumber the itemNumber to set
	 */
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	/**
	 * @return the serviceLevel
	 */
	public Double getServiceLevel() {
		return serviceLevel;
	}

	/**
	 * @param serviceLevel the serviceLevel to set
	 */
	public void setServiceLevel(Double serviceLevel) {
		this.serviceLevel = serviceLevel;
	}

	/**
	 * @return the modelExecutionDate
	 */
	public Date getModelExecutionDate() {
		return modelExecutionDate;
	}

	/**
	 * @param modelExecutionDate the modelExecutionDate to set
	 */
	public void setModelExecutionDate(Date modelExecutionDate) {
		this.modelExecutionDate = modelExecutionDate;
	}

	/**
	 * @return the unitPrice
	 */
	public Double getUnitPrice() {
		return unitPrice;
	}

	/**
	 * @param unitPrice the unitPrice to set
	 */
	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}

	/**
	 * @return the supplierType
	 */
	public String getSupplierType() {
		return supplierType;
	}

	/**
	 * @param supplierType the supplierType to set
	 */
	public void setSupplierType(String supplierType) {
		this.supplierType = supplierType;
	}

	/**
	 * @return the supplierCode
	 */
	public String getSupplierCode() {
		return supplierCode;
	}

	/**
	 * @param supplierCode the supplierCode to set
	 */
	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}

	/**
	 * @return the baselineInventoryQuantity
	 */
	public Double getBaselineInventoryQuantity() {
		return baselineInventoryQuantity;
	}

	/**
	 * @param baselineInventoryQuantity the baselineInventoryQuantity to set
	 */
	public void setBaselineInventoryQuantity(Double baselineInventoryQuantity) {
		this.baselineInventoryQuantity = baselineInventoryQuantity;
	}

	/**
	 * @return the baselineInventoryValue
	 */
	public Double getBaselineInventoryValue() {
		return baselineInventoryValue;
	}

	/**
	 * @param baselineInventoryValue the baselineInventoryValue to set
	 */
	public void setBaselineInventoryValue(Double baselineInventoryValue) {
		this.baselineInventoryValue = baselineInventoryValue;
	}

	/**
	 * @return the abcClassInventoryValue
	 */
	public Character getAbcClassInventoryValue() {
		return abcClassInventoryValue;
	}

	/**
	 * @param abcClassInventoryValue the abcClassInventoryValue to set
	 */
	public void setAbcClassInventoryValue(Character abcClassInventoryValue) {
		this.abcClassInventoryValue = abcClassInventoryValue;
	}

	/**
	 * @return the abcClassConsumptionValue
	 */
	public Character getAbcClassConsumptionValue() {
		return abcClassConsumptionValue;
	}

	/**
	 * @param abcClassConsumptionValue the abcClassConsumptionValue to set
	 */
	public void setAbcClassConsumptionValue(Character abcClassConsumptionValue) {
		this.abcClassConsumptionValue = abcClassConsumptionValue;
	}

	/**
	 * @return the xyzClassCoefficientOfVarianceDemandForecast
	 */
	public Character getXyzClassCoefficientOfVarianceDemandForecast() {
		return xyzClassCoefficientOfVarianceDemandForecast;
	}

	/**
	 * @param xyzClassCoefficientOfVarianceDemandForecast the
	 *                                                    xyzClassCoefficientOfVarianceDemandForecast
	 *                                                    to set
	 */
	public void setXyzClassCoefficientOfVarianceDemandForecast(Character xyzClassCoefficientOfVarianceDemandForecast) {
		this.xyzClassCoefficientOfVarianceDemandForecast = xyzClassCoefficientOfVarianceDemandForecast;
	}

	/**
	 * @return the minimumRanOrderQuantity
	 */
	public Double getMinimumRanOrderQuantity() {
		return minimumRanOrderQuantity;
	}

	/**
	 * @param minimumRanOrderQuantity the minimumRanOrderQuantity to set
	 */
	public void setMinimumRanOrderQuantity(Double minimumRanOrderQuantity) {
		this.minimumRanOrderQuantity = minimumRanOrderQuantity;
	}

	/**
	 * @return the snqQuantity
	 */
	public Double getSnqQuantity() {
		return snqQuantity;
	}

	/**
	 * @param snqQuantity the snqQuantity to set
	 */
	public void setSnqQuantity(Double snqQuantity) {
		this.snqQuantity = snqQuantity;
	}

	/**
	 * @return the floatRecommendedDays
	 */
	public Double getFloatRecommendedDays() {
		return floatRecommendedDays;
	}

	/**
	 * @param floatRecommendedDays the floatRecommendedDays to set
	 */
	public void setFloatRecommendedDays(Double floatRecommendedDays) {
		this.floatRecommendedDays = floatRecommendedDays;
	}

	/**
	 * @return the operationalReserveQuantity
	 */
	public Double getOperationalReserveQuantity() {
		return operationalReserveQuantity;
	}

	/**
	 * @param operationalReserveQuantity the operationalReserveQuantity to set
	 */
	public void setOperationalReserveQuantity(Double operationalReserveQuantity) {
		this.operationalReserveQuantity = operationalReserveQuantity;
	}

	/**
	 * @return the operationalReserveValue
	 */
	public Double getOperationalReserveValue() {
		return operationalReserveValue;
	}

	/**
	 * @param operationalReserveValue the operationalReserveValue to set
	 */
	public void setOperationalReserveValue(Double operationalReserveValue) {
		this.operationalReserveValue = operationalReserveValue;
	}

	/**
	 * @return the directPipelineStockQuantity
	 */
	public Double getDirectPipelineStockQuantity() {
		return directPipelineStockQuantity;
	}

	/**
	 * @param directPipelineStockQuantity the directPipelineStockQuantity to set
	 */
	public void setDirectPipelineStockQuantity(Double directPipelineStockQuantity) {
		this.directPipelineStockQuantity = directPipelineStockQuantity;
	}

	/**
	 * @return the ilcPipelineStockQuantity
	 */
	public Double getIlcPipelineStockQuantity() {
		return ilcPipelineStockQuantity;
	}

	/**
	 * @param ilcPipelineStockQuantity the ilcPipelineStockQuantity to set
	 */
	public void setIlcPipelineStockQuantity(Double ilcPipelineStockQuantity) {
		this.ilcPipelineStockQuantity = ilcPipelineStockQuantity;
	}

	/**
	 * @return the scrapPercentageToAnnualDemand
	 */
	public Double getScrapPercentageToAnnualDemand() {
		return scrapPercentageToAnnualDemand;
	}

	/**
	 * @param scrapPercentageToAnnualDemand the scrapPercentageToAnnualDemand to set
	 */
	public void setScrapPercentageToAnnualDemand(Double scrapPercentageToAnnualDemand) {
		this.scrapPercentageToAnnualDemand = scrapPercentageToAnnualDemand;
	}

	/**
	 * @return the cycleLossPercentageTotalAnnualDemand
	 */
	public Double getCycleLossPercentageTotalAnnualDemand() {
		return cycleLossPercentageTotalAnnualDemand;
	}

	/**
	 * @param cycleLossPercentageTotalAnnualDemand the
	 *                                             cycleLossPercentageTotalAnnualDemand
	 *                                             to set
	 */
	public void setCycleLossPercentageTotalAnnualDemand(Double cycleLossPercentageTotalAnnualDemand) {
		this.cycleLossPercentageTotalAnnualDemand = cycleLossPercentageTotalAnnualDemand;
	}

	/**
	 * @return the totalRecommendedFloatHours
	 */
	public Double getTotalRecommendedFloatHours() {
		return totalRecommendedFloatHours;
	}

	/**
	 * @param totalRecommendedFloatHours the totalRecommendedFloatHours to set
	 */
	public void setTotalRecommendedFloatHours(Double totalRecommendedFloatHours) {
		this.totalRecommendedFloatHours = totalRecommendedFloatHours;
	}

	/**
	 * @return the totalRecommendedFloatDays
	 */
	public Double getTotalRecommendedFloatDays() {
		return totalRecommendedFloatDays;
	}

	/**
	 * @param totalRecommendedFloatDays the totalRecommendedFloatDays to set
	 */
	public void setTotalRecommendedFloatDays(Double totalRecommendedFloatDays) {
		this.totalRecommendedFloatDays = totalRecommendedFloatDays;
	}

	/**
	 * @return the floatInventorySavings
	 */
	public Double getFloatInventorySavings() {
		return floatInventorySavings;
	}

	/**
	 * @param floatInventorySavings the floatInventorySavings to set
	 */
	public void setFloatInventorySavings(Double floatInventorySavings) {
		this.floatInventorySavings = floatInventorySavings;
	}

	/**
	 * @return the minimumRecommendedFloatHours
	 */
	public Double getMinimumRecommendedFloatHours() {
		return minimumRecommendedFloatHours;
	}

	/**
	 * @param minimumRecommendedFloatHours the minimumRecommendedFloatHours to set
	 */
	public void setMinimumRecommendedFloatHours(Double minimumRecommendedFloatHours) {
		this.minimumRecommendedFloatHours = minimumRecommendedFloatHours;
	}

	/**
	 * @return the minimumRecommendedFloatDays
	 */
	public Double getMinimumRecommendedFloatDays() {
		return minimumRecommendedFloatDays;
	}

	/**
	 * @param minimumRecommendedFloatDays the minimumRecommendedFloatDays to set
	 */
	public void setMinimumRecommendedFloatDays(Double minimumRecommendedFloatDays) {
		this.minimumRecommendedFloatDays = minimumRecommendedFloatDays;
	}

	/**
	 * @return the minimumFloatQuantity
	 */
	public Double getMinimumFloatQuantity() {
		return minimumFloatQuantity;
	}

	/**
	 * @param minimumFloatQuantity the minimumFloatQuantity to set
	 */
	public void setMinimumFloatQuantity(Double minimumFloatQuantity) {
		this.minimumFloatQuantity = minimumFloatQuantity;
	}

	/**
	 * @return the changePerRecommendedFloatValue
	 */
	public Double getChangePerRecommendedFloatValue() {
		return changePerRecommendedFloatValue;
	}

	/**
	 * @param changePerRecommendedFloatValue the changePerRecommendedFloatValue to
	 *                                       set
	 */
	public void setChangePerRecommendedFloatValue(Double changePerRecommendedFloatValue) {
		this.changePerRecommendedFloatValue = changePerRecommendedFloatValue;
	}

	/**
	 * @return the partsCategory
	 */
	public String getPartsCategory() {
		return partsCategory;
	}

	/**
	 * @param partsCategory the partsCategory to set
	 */
	public void setPartsCategory(String partsCategory) {
		this.partsCategory = partsCategory;
	}

	/**
	 * @return the partsController
	 */
	public String getPartsController() {
		return partsController;
	}

	/**
	 * @param partsController the partsController to set
	 */
	public void setPartsController(String partsController) {
		this.partsController = partsController;
	}

}
