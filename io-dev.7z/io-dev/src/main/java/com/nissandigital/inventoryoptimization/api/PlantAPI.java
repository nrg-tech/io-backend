package com.nissandigital.inventoryoptimization.api;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nissandigital.inventoryoptimization.dto.InventoryOptimizationError;
import com.nissandigital.inventoryoptimization.dto.PlantDetailsDTO;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RequestMapping(value = "plant")
public interface PlantAPI {

	@ApiOperation(value = "Fetch a list of plant information that the current user can access ", nickname = "getPlantInformation", notes = "Returns a list of plant information that the current user can access", response = PlantDetailsDTO.class, tags = {
			"plant" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Plant information successfully fetched for current user", response = PlantDetailsDTO.class),
			@ApiResponse(code = 404, message = "Plants not found for current user", response = InventoryOptimizationError.class) })
	@GetMapping(value = "/plant-information", produces = { "application/json" })
	ResponseEntity<List<PlantDetailsDTO>> getPlantInformation();
}
