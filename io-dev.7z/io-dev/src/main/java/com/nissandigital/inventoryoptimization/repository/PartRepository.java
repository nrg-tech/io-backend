package com.nissandigital.inventoryoptimization.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.nissandigital.inventoryoptimization.entity.PartEntity;

/**
 * Repository class for performing database operations on Part entity
 * 
 * @author Nissan Digital
 *
 */
public interface PartRepository extends CrudRepository<PartEntity, Long> {

	List<PartEntity> findByPartIdIn(List<Long> partIdList);

}
