package com.nissandigital.inventoryoptimization.api;

import java.util.List;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nissandigital.inventoryoptimization.dto.CategoryDTO;
import com.nissandigital.inventoryoptimization.dto.PartCategoryDTO;
import com.nissandigital.inventoryoptimization.dto.PartDetailsDTO;
import com.nissandigital.inventoryoptimization.dto.PartsCategoryMappingDTO;
import com.nissandigital.inventoryoptimization.dto.Status;
import com.nissandigital.inventoryoptimization.exception.NoDataFoundException;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RequestMapping(value = "parts-categories")
public interface PartsCategoryApi {
	@ApiOperation(value = "Mapping the  parts with specific parts category", nickname = "PartsCategory", notes = "", tags = {
			"PartsCategory" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Parts are successfully mapped with Part Category", response = Status.class),
			@ApiResponse(code = 404, message = "Category id not found", response = NoDataFoundException.class) })
	@PostMapping(value = "/category-mapping", produces = { "application/json" }, consumes = { "application/json" })
	ResponseEntity<Status> addPartsToPartsCategory(
			@ApiParam(value = "Parts that needs to be mapped with Parts Category in inventory optimization", required = true) @Valid @RequestBody PartsCategoryMappingDTO partsCategoryMappingDTO);

	@ApiOperation(value = "Adding the new parts category", nickname = "addPartsCategory", notes = "", tags = {
			"PartsCategory" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "New Part Category is Successfully added", response = Status.class),
			@ApiResponse(code = 404, message = "Part category or Plant Code is invalid", response = NoDataFoundException.class) })
	@PostMapping(produces = { "application/json" }, consumes = { "application/json" })
	ResponseEntity<Status> addPartsCategory(
			@ApiParam(value = "Adding new  Parts Category in inventory optimization", required = true) @Valid @RequestBody PartCategoryDTO partCategoryDTO);

	@ApiOperation(value = "Fetch the information of all the categories", nickname = "getCategories", notes = "Returns the information of all the categories ", response = CategoryDTO.class, tags = {
			"category" })
	@ApiResponse(code = 200, message = "Category information successfully fetched", response = CategoryDTO.class)
	@GetMapping(produces = { "application/json" })
	ResponseEntity<List<CategoryDTO>> getCategories();

	@ApiOperation(value = "Fetch the information of category parts", nickname = "getPartsByCategory", notes = "Returns the information of all parts for category ", response = String.class, tags = {
			"category" })
	@ApiResponse(code = 200, message = "Parts successfully fetched for Category", response = PartDetailsDTO.class)
	@GetMapping(value = "/{categoryId}", produces = { "application/json" })
	ResponseEntity<List<PartDetailsDTO>> getPartsByCategoryId(
			@ApiParam(value = "Parts of category to return", required = true) @PathVariable("categoryId") long categoryId);

	@ApiOperation(value = "Fetch the information of parts for unmapped category", nickname = "getUnmappedtParts", notes = "Returns the information of all unmapped parts for category ", response = PartDetailsDTO.class, tags = {
			"category" })
	@ApiResponse(code = 200, message = "UnmappedParts successfully fetched ", response = PartDetailsDTO.class)
	@GetMapping(value="/get-unmapped-parts",produces = { "application/json" })
	ResponseEntity<List<PartDetailsDTO>> getUnmappedParts();

}
