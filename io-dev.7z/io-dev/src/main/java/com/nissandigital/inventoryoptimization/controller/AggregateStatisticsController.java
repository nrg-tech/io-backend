package com.nissandigital.inventoryoptimization.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.nissandigital.inventoryoptimization.api.AggregateStatisticsApi;
import com.nissandigital.inventoryoptimization.dto.AggregateStatisticsDTO;
import com.nissandigital.inventoryoptimization.service.AggregateStatisticsService;

import io.swagger.annotations.Api;

/**
 * Controller which handles statistics
 * 
 * @author Nissan Digital
 *
 */
@RestController
@Api(tags = "Aggregate statistics")
public class AggregateStatisticsController implements AggregateStatisticsApi {

	@Autowired
	AggregateStatisticsService aggregateStatisticsService;

	@Override
	public ResponseEntity<AggregateStatisticsDTO> getAggregateStatistics() {
		return new ResponseEntity<>(aggregateStatisticsService.getAggregateStatistics(), HttpStatus.OK);
	}

}