package com.nissandigital.inventoryoptimization.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import io.swagger.annotations.Api;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.service.Tag;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

/**
 * Customization of swagger configuration
 * 
 * @author Nissan Digital
 *
 */
@Component
public class SwaggerDocumentationConfig {
	 @Bean
	 ApiInfo apiInfo() {
	        return new ApiInfoBuilder()
	            .title("InventoryOptimization Certification Management")
	            .description("InventoryOptimization for managing safety stock")
	            .license("Apache 2.0")
	            .licenseUrl("http://www.apache.org/licenses/LICENSE-2.0.html")
	            .termsOfServiceUrl("")
	            .version("1.0.0")
	            .contact(new Contact("","", "inventoryOptimization-support@nissanmotor.com"))
	            .build();
	    }

	    @Bean
	    public Docket customImplementation(){
	        return new Docket(DocumentationType.SWAGGER_2)
	                .select()
	                    .apis(RequestHandlerSelectors.withClassAnnotation(Api.class))
	                    .build().apiInfo(apiInfo())
	                    .tags(new Tag("Part", "APIs for handling part details"),
	                    		new Tag("plant","APIs for handling plant details"),
	                    		new Tag("Aggregate statistics","APIs for handling aggregate details"),
	                    		new Tag("Top-parts statistics","APIs for handling top-parts details"),
	                    		new Tag("user", "APIs for handling user details"),
	                            new Tag("Supplier", "APIs for handling all the supplier details"),
	                    		new Tag("LastRun","APIs for handling last run details"));
	    }

}

