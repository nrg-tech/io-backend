package com.nissandigital.inventoryoptimization.dto;


public class SupplierDTO {

	private long id;
	private String supplierCode;
	private String name;

	
	public String getSupplierCode() {
		return supplierCode;
	}

	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "SupplierDTO [id=" + id + ", name=" + name + "]";
	}

	
	
}
