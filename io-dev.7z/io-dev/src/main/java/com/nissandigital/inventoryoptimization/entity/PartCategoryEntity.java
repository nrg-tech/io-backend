package com.nissandigital.inventoryoptimization.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "io_part_category_master",schema = "io_stat_model")
public class PartCategoryEntity {
	@Id
	@Column(name = "PART_CATEGORY_ID")
	private long partCategoryId;

	@Column(name = "PLANT_ID")
	private long plantId;
	
	@Column(name = "PART_CATEGORY_DESC")
	private String partCategoryDescription;

	@Column(name = "CREATED_BY")
	private long createdBy;

	@Column(name = "CREATED_DT")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;

	@Column(name = "UPD_BY")
	private long updatedBy;

	@Column(name = "UPD_DT")
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedDate;
	
	
	@ManyToOne(cascade= CascadeType.ALL)
    @JoinColumn(name = "PLANT_ID", referencedColumnName = "PLANT_ID",insertable = false, updatable = false)
    private PlantEntity plantEntity;
	
	@OneToMany(mappedBy = "partCategoryEntity", cascade = CascadeType.ALL)
    private List<PartCategoryMappingEntity> partCategoryMappingEntities;
	
	public PartCategoryEntity() {
	}

	public long getPartCategoryId() {
		return partCategoryId;
	}

	public void setPartCategoryId(long partCategoryId) {
		this.partCategoryId = partCategoryId;
	}

	public long getPlantId() {
		return plantId;
	}

	public void setPlantId(long plantId) {
		this.plantId = plantId;
	}

	public String getPartCategoryDescription() {
		return partCategoryDescription;
	}

	public void setPartCategoryDescription(String partCategoryDescription) {
		this.partCategoryDescription = partCategoryDescription;
	}

	public long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public long getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(long updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	@Override
	public String toString() {
		return "PartCategoryEntity [partCategoryId=" + partCategoryId + ", plantId=" + plantId
				+ ", partCategoryDescription=" + partCategoryDescription + ", createdBy=" + createdBy + ", createdDate="
				+ createdDate + ", updatedBy=" + updatedBy + ", updatedDate=" + updatedDate + "]";
	}

	
    
}
