package com.nissandigital.inventoryoptimization.constants;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Constants used for GD Authentication
 * 
 * @author Nissan Digital
 *
 */
public class AuthenticationConstants {

	  public static final String USER_HEADER = "cn";
	    
	    private static final String [] FILTER_EXCLUDE_PATH = 
	    	{"swagger-ui.html","swagger-resources","springfox-swagger-ui","csrf","v2/api-docs"};
	    
	    public static final List<String> FILTER_EXCLUDE_PATHS =
	      Collections.unmodifiableList(Arrays.asList(FILTER_EXCLUDE_PATH));

}
