package com.nissandigital.inventoryoptimization.dto;

import java.util.Date;

/**
 * DTO class containing Last Run Table details
 * 
 * @author Nissan Digital
 *
 */
public class LastRunDTO {

	private String plantCode;

	private String itemNumber;

	private Double serviceLevel;

	private Date modelExecutionDate;

	private Double unitPrice;

	private String supplierType;

	private String supplierCode;

	private Double baselineInventoryQuantity;

	private Double baselineInventoryValue;

	private Character abcClassInventoryValue;

	private Character abcClassConsumptionValue;

	private Character xyzClassCoefficientOfVarianceDemandForecast;

	private Double minimumRanOrderQuantity;

	private Double snqQuantity;

	private Double floatRecommendedDays;

	private Double operationalReserveQuantity;

	private Double operationalReserveValue;

	private Double directPipelineStockQuantity;

	private Double ilcPipelineStockQuantity;

	private Double scrapPercentageToAnnualDemand;

	private Double cycleLossPercentageTotalAnnualDemand;

	private Double totalRecommendedFloatHours;

	private Double totalRecommendedFloatDays;

	private Double floatInventorySavings;

	private Double minimumRecommendedFloatHours;

	private Double minimumRecommendedFloatDays;

	private Double minimumFloatQuantity;

	private Double changePerRecommendedFloatValue;

	private String partsCategory;

	private String partsController;

	private String partTypeCode;

	/**
	 * @return the partTypeCode
	 */
	public String getPartTypeCode() {
		return partTypeCode;
	}

	/**
	 * @param partTypeCode the partTypeCode to set
	 */
	public void setPartTypeCode(String partTypeCode) {
		this.partTypeCode = partTypeCode;
	}

	/**
	 * @return the plantCode
	 */
	public String getPlantCode() {
		return plantCode;
	}

	/**
	 * @param plantCode the plantCode to set
	 */
	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}

	/**
	 * @return the itemNumber
	 */
	public String getItemNumber() {
		return itemNumber;
	}

	/**
	 * @param itemNumber the itemNumber to set
	 */
	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	/**
	 * @return the serviceLevel
	 */
	public Double getServiceLevel() {
		return serviceLevel;
	}

	/**
	 * @param serviceLevel the serviceLevel to set
	 */
	public void setServiceLevel(Double serviceLevel) {
		this.serviceLevel = serviceLevel;
	}

	/**
	 * @return the modelExecutionDate
	 */
	public Date getModelExecutionDate() {
		return modelExecutionDate;
	}

	/**
	 * @param modelExecutionDate the modelExecutionDate to set
	 */
	public void setModelExecutionDate(Date modelExecutionDate) {
		this.modelExecutionDate = modelExecutionDate;
	}

	/**
	 * @return the unitPrice
	 */
	public Double getUnitPrice() {
		return unitPrice;
	}

	/**
	 * @param unitPrice the unitPrice to set
	 */
	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}

	/**
	 * @return the supplierType
	 */
	public String getSupplierType() {
		return supplierType;
	}

	/**
	 * @param supplierType the supplierType to set
	 */
	public void setSupplierType(String supplierType) {
		this.supplierType = supplierType;
	}

	/**
	 * @return the supplierCode
	 */
	public String getSupplierCode() {
		return supplierCode;
	}

	/**
	 * @param supplierCode the supplierCode to set
	 */
	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}

	/**
	 * @return the baselineInventoryQuantity
	 */
	public Double getBaselineInventoryQuantity() {
		return baselineInventoryQuantity;
	}

	/**
	 * @param baselineInventoryQuantity the baselineInventoryQuantity to set
	 */
	public void setBaselineInventoryQuantity(Double baselineInventoryQuantity) {
		this.baselineInventoryQuantity = baselineInventoryQuantity;
	}

	/**
	 * @return the baselineInventoryValue
	 */
	public Double getBaselineInventoryValue() {
		return baselineInventoryValue;
	}

	/**
	 * @param baselineInventoryValue the baselineInventoryValue to set
	 */
	public void setBaselineInventoryValue(Double baselineInventoryValue) {
		this.baselineInventoryValue = baselineInventoryValue;
	}

	/**
	 * @return the abcClassInventoryValue
	 */
	public Character getAbcClassInventoryValue() {
		return abcClassInventoryValue;
	}

	/**
	 * @param abcClassInventoryValue the abcClassInventoryValue to set
	 */
	public void setAbcClassInventoryValue(Character abcClassInventoryValue) {
		this.abcClassInventoryValue = abcClassInventoryValue;
	}

	/**
	 * @return the abcClassConsumptionValue
	 */
	public Character getAbcClassConsumptionValue() {
		return abcClassConsumptionValue;
	}

	/**
	 * @param abcClassConsumptionValue the abcClassConsumptionValue to set
	 */
	public void setAbcClassConsumptionValue(Character abcClassConsumptionValue) {
		this.abcClassConsumptionValue = abcClassConsumptionValue;
	}

	/**
	 * @return the xyzClassCoefficientOfVarianceDemandForecast
	 */
	public Character getXyzClassCoefficientOfVarianceDemandForecast() {
		return xyzClassCoefficientOfVarianceDemandForecast;
	}

	/**
	 * @param xyzClassCoefficientOfVarianceDemandForecast the
	 *                                                    xyzClassCoefficientOfVarianceDemandForecast
	 *                                                    to set
	 */
	public void setXyzClassCoefficientOfVarianceDemandForecast(Character xyzClassCoefficientOfVarianceDemandForecast) {
		this.xyzClassCoefficientOfVarianceDemandForecast = xyzClassCoefficientOfVarianceDemandForecast;
	}

	/**
	 * @return the minimumRanOrderQuantity
	 */
	public Double getMinimumRanOrderQuantity() {
		return minimumRanOrderQuantity;
	}

	/**
	 * @param minimumRanOrderQuantity the minimumRanOrderQuantity to set
	 */
	public void setMinimumRanOrderQuantity(Double minimumRanOrderQuantity) {
		this.minimumRanOrderQuantity = minimumRanOrderQuantity;
	}

	/**
	 * @return the snqQuantity
	 */
	public Double getSnqQuantity() {
		return snqQuantity;
	}

	/**
	 * @param snqQuantity the snqQuantity to set
	 */
	public void setSnqQuantity(Double snqQuantity) {
		this.snqQuantity = snqQuantity;
	}

	/**
	 * @return the floatRecommendedDays
	 */
	public Double getFloatRecommendedDays() {
		return floatRecommendedDays;
	}

	/**
	 * @param floatRecommendedDays the floatRecommendedDays to set
	 */
	public void setFloatRecommendedDays(Double floatRecommendedDays) {
		this.floatRecommendedDays = floatRecommendedDays;
	}

	/**
	 * @return the operationalReserveQuantity
	 */
	public Double getOperationalReserveQuantity() {
		return operationalReserveQuantity;
	}

	/**
	 * @param operationalReserveQuantity the operationalReserveQuantity to set
	 */
	public void setOperationalReserveQuantity(Double operationalReserveQuantity) {
		this.operationalReserveQuantity = operationalReserveQuantity;
	}

	/**
	 * @return the operationalReserveValue
	 */
	public Double getOperationalReserveValue() {
		return operationalReserveValue;
	}

	/**
	 * @param operationalReserveValue the operationalReserveValue to set
	 */
	public void setOperationalReserveValue(Double operationalReserveValue) {
		this.operationalReserveValue = operationalReserveValue;
	}

	/**
	 * @return the directPipelineStockQuantity
	 */
	public Double getDirectPipelineStockQuantity() {
		return directPipelineStockQuantity;
	}

	/**
	 * @param directPipelineStockQuantity the directPipelineStockQuantity to set
	 */
	public void setDirectPipelineStockQuantity(Double directPipelineStockQuantity) {
		this.directPipelineStockQuantity = directPipelineStockQuantity;
	}

	/**
	 * @return the ilcPipelineStockQuantity
	 */
	public Double getIlcPipelineStockQuantity() {
		return ilcPipelineStockQuantity;
	}

	/**
	 * @param ilcPipelineStockQuantity the ilcPipelineStockQuantity to set
	 */
	public void setIlcPipelineStockQuantity(Double ilcPipelineStockQuantity) {
		this.ilcPipelineStockQuantity = ilcPipelineStockQuantity;
	}

	/**
	 * @return the scrapPercentageToAnnualDemand
	 */
	public Double getScrapPercentageToAnnualDemand() {
		return scrapPercentageToAnnualDemand;
	}

	/**
	 * @param scrapPercentageToAnnualDemand the scrapPercentageToAnnualDemand to set
	 */
	public void setScrapPercentageToAnnualDemand(Double scrapPercentageToAnnualDemand) {
		this.scrapPercentageToAnnualDemand = scrapPercentageToAnnualDemand;
	}

	/**
	 * @return the cycleLossPercentageTotalAnnualDemand
	 */
	public Double getCycleLossPercentageTotalAnnualDemand() {
		return cycleLossPercentageTotalAnnualDemand;
	}

	/**
	 * @param cycleLossPercentageTotalAnnualDemand the
	 *                                             cycleLossPercentageTotalAnnualDemand
	 *                                             to set
	 */
	public void setCycleLossPercentageTotalAnnualDemand(Double cycleLossPercentageTotalAnnualDemand) {
		this.cycleLossPercentageTotalAnnualDemand = cycleLossPercentageTotalAnnualDemand;
	}

	/**
	 * @return the totalRecommendedFloatHours
	 */
	public Double getTotalRecommendedFloatHours() {
		return totalRecommendedFloatHours;
	}

	/**
	 * @param totalRecommendedFloatHours the totalRecommendedFloatHours to set
	 */
	public void setTotalRecommendedFloatHours(Double totalRecommendedFloatHours) {
		this.totalRecommendedFloatHours = totalRecommendedFloatHours;
	}

	/**
	 * @return the totalRecommendedFloatDays
	 */
	public Double getTotalRecommendedFloatDays() {
		return totalRecommendedFloatDays;
	}

	/**
	 * @param totalRecommendedFloatDays the totalRecommendedFloatDays to set
	 */
	public void setTotalRecommendedFloatDays(Double totalRecommendedFloatDays) {
		this.totalRecommendedFloatDays = totalRecommendedFloatDays;
	}

	/**
	 * @return the floatInventorySavings
	 */
	public Double getFloatInventorySavings() {
		return floatInventorySavings;
	}

	/**
	 * @param floatInventorySavings the floatInventorySavings to set
	 */
	public void setFloatInventorySavings(Double floatInventorySavings) {
		this.floatInventorySavings = floatInventorySavings;
	}

	/**
	 * @return the minimumRecommendedFloatHours
	 */
	public Double getMinimumRecommendedFloatHours() {
		return minimumRecommendedFloatHours;
	}

	/**
	 * @param minimumRecommendedFloatHours the minimumRecommendedFloatHours to set
	 */
	public void setMinimumRecommendedFloatHours(Double minimumRecommendedFloatHours) {
		this.minimumRecommendedFloatHours = minimumRecommendedFloatHours;
	}

	/**
	 * @return the minimumRecommendedFloatDays
	 */
	public Double getMinimumRecommendedFloatDays() {
		return minimumRecommendedFloatDays;
	}

	/**
	 * @param minimumRecommendedFloatDays the minimumRecommendedFloatDays to set
	 */
	public void setMinimumRecommendedFloatDays(Double minimumRecommendedFloatDays) {
		this.minimumRecommendedFloatDays = minimumRecommendedFloatDays;
	}

	/**
	 * @return the minimumFloatQuantity
	 */
	public Double getMinimumFloatQuantity() {
		return minimumFloatQuantity;
	}

	/**
	 * @param minimumFloatQuantity the minimumFloatQuantity to set
	 */
	public void setMinimumFloatQuantity(Double minimumFloatQuantity) {
		this.minimumFloatQuantity = minimumFloatQuantity;
	}

	/**
	 * @return the changePerRecommendedFloatValue
	 */
	public Double getChangePerRecommendedFloatValue() {
		return changePerRecommendedFloatValue;
	}

	/**
	 * @param changePerRecommendedFloatValue the changePerRecommendedFloatValue to
	 *                                       set
	 */
	public void setChangePerRecommendedFloatValue(Double changePerRecommendedFloatValue) {
		this.changePerRecommendedFloatValue = changePerRecommendedFloatValue;
	}

	/**
	 * @return the partsCategory
	 */
	public String getPartsCategory() {
		return partsCategory;
	}

	/**
	 * @param partsCategory the partsCategory to set
	 */
	public void setPartsCategory(String partsCategory) {
		this.partsCategory = partsCategory;
	}

	/**
	 * @return the partsController
	 */
	public String getPartsController() {
		return partsController;
	}

	/**
	 * @param partsController the partsController to set
	 */
	public void setPartsController(String partsController) {
		this.partsController = partsController;
	}

}