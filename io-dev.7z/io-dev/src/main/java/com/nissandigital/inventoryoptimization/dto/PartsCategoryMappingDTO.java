package com.nissandigital.inventoryoptimization.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * DTO class containing parts to parts category mapping
 * 
 * @author Nissan Digital
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PartsCategoryMappingDTO {

	private long categoryId;
	private List<Long> partIds;

	public long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(long categoryId) {
		this.categoryId = categoryId;
	}

	public List<Long> getPartIds() {
		return partIds;
	}

	public void setPartIds(List<Long> partIds) {
		this.partIds = partIds;
	}

	public PartsCategoryMappingDTO(long categoryId, List<Long> partIds) {
		super();
		this.categoryId = categoryId;
		this.partIds = partIds;
	}
    
	public PartsCategoryMappingDTO() {
		super();
	}

	@Override
	public String toString() {
		return "PartsCategoryMappingDTO [categoryId=" + categoryId + ", partIds=" + partIds + "]";
	}

}
