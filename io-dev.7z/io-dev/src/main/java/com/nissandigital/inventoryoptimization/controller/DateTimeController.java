package com.nissandigital.inventoryoptimization.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.nissandigital.inventoryoptimization.api.DateTimeApi;
import com.nissandigital.inventoryoptimization.dto.DateTimeDTO;
import com.nissandigital.inventoryoptimization.service.DateTimeService;

import io.swagger.annotations.Api;

/**
 * Controller which handles Date and Time information
 * 
 * @author Nissan Digital
 *
 */
@RestController
@Api(tags = "dateTime")
public class DateTimeController implements DateTimeApi {

	@Autowired
	DateTimeService dateTimeService;

	@Override
	public ResponseEntity<DateTimeDTO> getCurrentDateTime() {
		return new ResponseEntity<DateTimeDTO>(dateTimeService.getCurrentDateTime(), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<DateTimeDTO> getModelExecutionDate(Integer plantId) {
		return new ResponseEntity<DateTimeDTO>(dateTimeService.getModelExecutionDate(plantId), HttpStatus.OK);
	}

}
