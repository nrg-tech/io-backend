package com.nissandigital.inventoryoptimization.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.nissandigital.inventoryoptimization.api.UserApi;
import com.nissandigital.inventoryoptimization.dto.RoleDTO;
import com.nissandigital.inventoryoptimization.dto.UserDetailsDTO;
import com.nissandigital.inventoryoptimization.service.UserService;

import io.swagger.annotations.Api;

/**
 * Controller which handles user information
 * 
 * @author Nissan Digital
 *
 */
@RestController
@Api(tags = "user")
public class UserController implements UserApi {

	@Autowired
	UserService userService;
	

	@Override
	public ResponseEntity<UserDetailsDTO> getCurrentUser() {
		return new ResponseEntity<>(userService.getCurrentUser(), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<UserDetailsDTO>> getUsersByRole(String role) {
		List<UserDetailsDTO> roleDTO =userService.findUserByRole(role);
		return new ResponseEntity<>(roleDTO, HttpStatus.OK);
	}
}
