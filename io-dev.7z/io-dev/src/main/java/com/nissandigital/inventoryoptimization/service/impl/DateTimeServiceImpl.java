package com.nissandigital.inventoryoptimization.service.impl;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nissandigital.inventoryoptimization.dto.DateTimeDTO;
import com.nissandigital.inventoryoptimization.repository.PlantRepository;
import com.nissandigital.inventoryoptimization.repository.StatisticalMVMetricsRepository;
import com.nissandigital.inventoryoptimization.service.DateTimeService;

/**
 * Implementation class for date time service
 * 
 * @author Nissan Digital
 *
 */
@Service
public class DateTimeServiceImpl implements DateTimeService {

	@Autowired
	StatisticalMVMetricsRepository metricsRepository;
	@Autowired
	PlantRepository plantMaster;

	@Override
	public DateTimeDTO getCurrentDateTime() {
		DateTimeDTO response = new DateTimeDTO();
		ZoneId zoneId = ZoneId.of("UTC");
		LocalDateTime dateTime = LocalDateTime.ofInstant((new Date()).toInstant(), zoneId);
		response.setDate(Date.from(dateTime.atZone(zoneId).toInstant()));
		return response;
	}

	@Override
	public DateTimeDTO getModelExecutionDate(Integer plantId) {
		DateTimeDTO dto = new DateTimeDTO();
		dto.setDate(metricsRepository.findById(plantId).get().getModelExecutionDate());
		dto.setTimeZone(plantMaster.findById(plantId).get().getTimeZone());
		return dto;
	}

}
