package com.nissandigital.inventoryoptimization.exception;

public class ValidationException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8499785734694134878L;

	public ValidationException() {
		super();
	}

	public ValidationException(String message) {
		super(message);
	}

}
