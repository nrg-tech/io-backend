package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the part database table.
 * 
 */
@Entity
@Table(name = "IO_DWH_DIM_PARTS_MASTER",schema="io_stat_model")
public class PartEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "SK_PART_ID")
	private long partId;

	@Column(name = "PLANT_ID")
	private long plantId;

	@Column(name = "ITEM_NUM")
	private String itemNumber;

	@Column(name = "ITEM_DESC")
	private String itemDescription;

	@Column(name = "ITEM_TYPE")
	private String itemType;

	@Column(name = "PART_CLS_CD")
	private char partClassCode;

	@Column(name = "UNIT_PRICE")
	private double unitPrice;

	@Column(name = "OPRTNL_RSRV_QTY")
	private double operationalReserveQuantity;

	@Column(name = "MIN_RAN_ORDR_QTY")
	private double minRanOrderQuantity;

	@Column(name = "SNP_QTY")
	private double snpQuantity;

	@Column(name = "FLOAT_TYPE_USE_CD")
	private char floatTypeUseCd;

	@Column(name = "FLOAT_RECOM_DAYS")
	private double recommendedDays;

	@Column(name = "FLOAT_RECOM_HRS")
	private double recommendedHours;

	@Column(name = "FLOAT_COMMENTS")
	private String floatComments;

	@Column(name = "LOAD_DT")
	@Temporal(TemporalType.TIMESTAMP)
	private Date loadDate;

	@Column(name = "PART_TYPE_CD")
	private String partTypeCode;

	@OneToMany(mappedBy = "partEntity", cascade = CascadeType.ALL)
	private List<PartCategoryMappingEntity> partCategoryMappingEntities;

	public List<PartCategoryMappingEntity> getPartCategoryMappingEntities() {
		return partCategoryMappingEntities;
	}

	public void setPartCategoryMappingEntities(List<PartCategoryMappingEntity> partCategoryMappingEntities) {
		this.partCategoryMappingEntities = partCategoryMappingEntities;
	}

	public long getPartId() {
		return partId;
	}

	public void setPartId(long partId) {
		this.partId = partId;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public long getPlantId() {
		return plantId;
	}

	public void setPlantId(long plantId) {
		this.plantId = plantId;
	}

	public String getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public char getPartClassCode() {
		return partClassCode;
	}

	public void setPartClassCode(char partClassCode) {
		this.partClassCode = partClassCode;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public double getOperationalReserveQuantity() {
		return operationalReserveQuantity;
	}

	public void setOperationalReserveQuantity(double operationalReserveQuantity) {
		this.operationalReserveQuantity = operationalReserveQuantity;
	}

	public double getMinRanOrderQuantity() {
		return minRanOrderQuantity;
	}

	public void setMinRanOrderQuantity(double minRanOrderQuantity) {
		this.minRanOrderQuantity = minRanOrderQuantity;
	}

	public double getSnpQuantity() {
		return snpQuantity;
	}

	public void setSnpQuantity(double snpQuantity) {
		this.snpQuantity = snpQuantity;
	}

	public char getFloatTypeUseCd() {
		return floatTypeUseCd;
	}

	public void setFloatTypeUseCd(char floatTypeUseCd) {
		this.floatTypeUseCd = floatTypeUseCd;
	}

	public double getRecommendedDays() {
		return recommendedDays;
	}

	public void setRecommendedDays(double recommendedDays) {
		this.recommendedDays = recommendedDays;
	}

	public double getRecommendedHours() {
		return recommendedHours;
	}

	public void setRecommendedHours(double recommendedHours) {
		this.recommendedHours = recommendedHours;
	}

	public String getFloatComments() {
		return floatComments;
	}

	public void setFloatComments(String floatComments) {
		this.floatComments = floatComments;
	}

	public Date getLoadDate() {
		return loadDate;
	}

	public void setLoadDate(Date loadDate) {
		this.loadDate = loadDate;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getPartTypeCode() {
		return partTypeCode;
	}

	public void setPartTypeCode(String partTypeCode) {
		this.partTypeCode = partTypeCode;
	}

	@Override
	public String toString() {
		return "Part [partId=" + partId + ", plantId=" + plantId + ", itemNumber=" + itemNumber + ", itemDescription="
				+ itemDescription + ", partClassCode=" + partClassCode + ", unitPrice=" + unitPrice
				+ ", operationalReserveQuantity=" + operationalReserveQuantity + ", minRanOrderQuantity="
				+ minRanOrderQuantity + ", snpQuantity=" + snpQuantity + ", floatTypeUseCd=" + floatTypeUseCd
				+ ", recommendedDays=" + recommendedDays + ", recommendedHours=" + recommendedHours + ", floatComments="
				+ floatComments + ", loadDate=" + loadDate + "]";
	}

}