package com.nissandigital.inventoryoptimization.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * DTO class for adding a new Category
 * 
 * @author Nissan Digital
 *
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PartDetailsDTO {

	private String partNumber;
	private String partDescription;
	private String location;
	private String supplierName;
	private String partTypeCode;
	private String partController;
	
	
	public PartDetailsDTO() {
		
	}


	public String getPartNumber() {
		return partNumber;
	}


	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}


	public String getPartDescription() {
		return partDescription;
	}


	public void setPartDescription(String partDescription) {
		this.partDescription = partDescription;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public String getSupplierName() {
		return supplierName;
	}


	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}


	public String getPartTypeCode() {
		return partTypeCode;
	}


	public void setPartTypeCode(String partTypeCode) {
		this.partTypeCode = partTypeCode;
	}


	public String getPartController() {
		return partController;
	}


	public void setPartController(String partController) {
		this.partController = partController;
	}
	

}
