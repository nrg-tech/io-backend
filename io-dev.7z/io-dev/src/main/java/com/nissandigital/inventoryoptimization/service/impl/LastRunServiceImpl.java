package com.nissandigital.inventoryoptimization.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nissandigital.inventoryoptimization.dto.LastRunDTO;
import com.nissandigital.inventoryoptimization.entity.StatisticalModelOutputViewEntity;
import com.nissandigital.inventoryoptimization.repository.LastRunRepository;
import com.nissandigital.inventoryoptimization.service.LastRunService;

/**
 * @author Nissan Digital
 * 
 *         Implementation class for Last Run Details service
 *
 */
@Service
public class LastRunServiceImpl implements LastRunService {

	@Autowired
	LastRunRepository lastRunRepository;

	@Override
	public List<LastRunDTO> findLastRunDetailsByServiceLevel(double serviceLevel) {
		return lastRunRepository.findAllByServiceLevel(serviceLevel).stream().map(w->convertEntityToDTO(w)).collect(Collectors.toList());
	}
	
	public LastRunDTO convertEntityToDTO(StatisticalModelOutputViewEntity entity) {
		LastRunDTO dto = new LastRunDTO();
		dto.setPlantCode(entity.getPlantCode());
		dto.setItemNumber(entity.getItemNumber().trim());
		dto.setServiceLevel(entity.getServiceLevel());
		dto.setModelExecutionDate(entity.getModelExecutionDate());
		dto.setUnitPrice(entity.getUnitPrice());
		dto.setSupplierType(entity.getSupplierType());
		dto.setSupplierCode(entity.getSupplierCode());
		dto.setBaselineInventoryQuantity(entity.getBaselineInventoryQuantity());
		dto.setBaselineInventoryValue(entity.getBaselineInventoryValue());
		dto.setAbcClassConsumptionValue(entity.getAbcClassConsumptionValue());
		dto.setAbcClassInventoryValue(entity.getAbcClassInventoryValue());
		dto.setXyzClassCoefficientOfVarianceDemandForecast(entity.getXyzClassCoefficientOfVarianceDemandForecast());
		dto.setMinimumRanOrderQuantity(entity.getMinimumRanOrderQuantity());
		dto.setSnqQuantity(entity.getSnqQuantity());
		dto.setFloatRecommendedDays(entity.getFloatRecommendedDays());
		dto.setOperationalReserveQuantity(entity.getOperationalReserveQuantity());
		dto.setOperationalReserveValue(entity.getOperationalReserveValue());
		dto.setDirectPipelineStockQuantity(entity.getDirectPipelineStockQuantity());
		dto.setIlcPipelineStockQuantity(entity.getIlcPipelineStockQuantity());
		dto.setScrapPercentageToAnnualDemand(entity.getScrapPercentageToAnnualDemand());
		dto.setCycleLossPercentageTotalAnnualDemand(entity.getCycleLossPercentageTotalAnnualDemand());
		dto.setTotalRecommendedFloatDays(entity.getTotalRecommendedFloatDays());
		dto.setTotalRecommendedFloatHours(entity.getTotalRecommendedFloatHours());
		dto.setFloatInventorySavings(entity.getFloatInventorySavings());
		dto.setMinimumRecommendedFloatDays(entity.getMinimumRecommendedFloatDays());
		dto.setMinimumRecommendedFloatHours(entity.getMinimumRecommendedFloatHours());
		dto.setMinimumFloatQuantity(entity.getMinimumFloatQuantity());
		dto.setChangePerRecommendedFloatValue(entity.getChangePerRecommendedFloatValue());
		dto.setPartsCategory(entity.getPartsCategory());
		dto.setPartsController(entity.getPartsController());
		dto.setPartTypeCode(entity.getPartTypeCode());
		return dto;
	}
}
