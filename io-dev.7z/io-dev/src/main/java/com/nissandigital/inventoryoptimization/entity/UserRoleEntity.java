package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the "IO_USER_ROLE_MASTER" database table.
 * 
 */
@Entity
@Table(name="IO_USER_ROLE_MASTER", schema = "io_stat_model")
@NamedQuery(name="IoUserRoleMaster.findAll", query="SELECT i FROM UserRoleEntity i")
public class UserRoleEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="USER_ROLE_ID", unique=true, nullable=false)
	private long userRoleId;

	@Column(name="CREATED_BY", nullable=false)
	private long createdBy;

	@Column(name="CREATED_DT", nullable=false)
	private Timestamp createdDt;

	@Column(name="UPD_BY", nullable=false)
	private long updBy;

	@Column(name="UPD_DT", nullable=false)
	private Timestamp updDt;

	@Column(name="USER_ROLE_DESC", nullable=false, length=50)
	private String userRoleDesc;
	
	public UserRoleEntity() {
	}

	public long getUserRoleId() {
		return this.userRoleId;
	}

	public void setUserRoleId(long userRoleId) {
		this.userRoleId = userRoleId;
	}

	public long getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDt() {
		return this.createdDt;
	}

	public void setCreatedDt(Timestamp createdDt) {
		this.createdDt = createdDt;
	}

	public long getUpdBy() {
		return this.updBy;
	}

	public void setUpdBy(long updBy) {
		this.updBy = updBy;
	}

	public Timestamp getUpdDt() {
		return this.updDt;
	}

	public void setUpdDt(Timestamp updDt) {
		this.updDt = updDt;
	}

	public String getUserRoleDesc() {
		return this.userRoleDesc;
	}

	public void setUserRoleDesc(String userRoleDesc) {
		this.userRoleDesc = userRoleDesc;
	}

}