package com.nissandigital.inventoryoptimization.dto;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * DTO class containing filter details
 * 
 * @author Nissan Digital
 *
 */
public class FilterDTO {

	@JsonProperty("partsController")
	private List<RoleDTO> roleDTOs;

	@JsonProperty("supplier")
	private List<SupplierDTO> supplierDTOs ;
	@JsonProperty("category")
	private List<CategoryDTO> categoryDTOs;

	

	public List<RoleDTO> getPartControllerDTOs() {
		return roleDTOs;
	}

	public void setPartControllerDTOs(List<RoleDTO> roleDTOs) {
		this.roleDTOs = roleDTOs;
	}

	public List<SupplierDTO> getSupplierDTOs() {
		return supplierDTOs;
	}

	public void setSupplierDTOs(List<SupplierDTO> supplierDTOs) {
		this.supplierDTOs = supplierDTOs;
	}

	public List<CategoryDTO> getCategoryDTOs() {
		return categoryDTOs;
	}

	public void setCategoryDTOs(List<CategoryDTO> categoryDTOs) {
		this.categoryDTOs = categoryDTOs;
	}

	@Override
	public String toString() {
		return "FilterDTO [roleDTOs=" + roleDTOs + ", supplierDTOs=" + supplierDTOs
				+ ", categoryDTOs=" + categoryDTOs + "]";
	}

	
}