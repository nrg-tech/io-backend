package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

@Embeddable
public class UserPartsIdentity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9077818931365213315L;

	@NotNull
	@Column(name = "SK_PART_ID")
	private long partId;

	@NotNull
	@Column(name = "USER_ID")
	private long userId;

	public long getPartId() {
		return partId;
	}

	public void setPartId(long partId) {
		this.partId = partId;
	}

	public long getUserId() {
		return userId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

}
