package com.nissandigital.inventoryoptimization;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;

import springfox.documentation.swagger2.annotations.EnableSwagger2;
/**
 * Main Application Class
 * 
 * SpringBootApplication annotation initializes the application
 * 
 * @author Nissan Digital
 */
@SpringBootApplication(scanBasePackages = { "com.nissandigital.inventoryoptimization" })
@EnableSwagger2
public class InventoryOptimizationApplication extends SpringBootServletInitializer{

	/**
	 * Application main method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(InventoryOptimizationApplication.class, args);
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(InventoryOptimizationApplication.class);
	}
}







