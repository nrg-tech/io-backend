package com.nissandigital.inventoryoptimization.constants;

/**
 * Constant class which contains the API error messages
 * 
 * @author Nissan Digital
 *
 */
public class InventoryOptimizationErrorMessages {

	public static final String RESOURCE_OPERATION_FAILED_MESSAGE = "Unable to perform the requested operation. Kindly contact administrator";
	
}
