package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

/**
 * The persistent class for the part category database table.
 * 
 */
@Entity
@Table( name = "IO_PART_CATEGORY", schema = "io_stat_model",uniqueConstraints={
	    @UniqueConstraint(columnNames = {"PART_CATEGORY_ID","SK_PART_ID"} )} )
public class PartCategoryMappingEntity implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private PartCategoryMappingIdentity partCategoryMappingIdentity;
    	
	@Column(name ="CREATED_BY")
	private long createdBy;

	@Column(name = "CREATED_DT")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;

	@Column(name = "UPD_BY")
	private long updatedBy;

	@Column(name = "UPD_DT")
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedDate;
	
	@ManyToOne(cascade= CascadeType.ALL)
    @JoinColumn(name = "SK_PART_ID", referencedColumnName = "SK_PART_ID",insertable = false, updatable = false)
    private PartEntity partEntity;
	
	@ManyToOne(cascade= CascadeType.ALL)
    @JoinColumn(name = "PART_CATEGORY_ID", referencedColumnName = "PART_CATEGORY_ID",insertable = false, updatable = false)
    private PartCategoryEntity partCategoryEntity;
	
	

	
	public long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(long createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Long getUpdatedBy() {
		return updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public PartCategoryMappingIdentity getPartCategoryMappingIdentity() {
		return partCategoryMappingIdentity;
	}

	public void setPartCategoryMappingIdentity(PartCategoryMappingIdentity partCategoryMappingIdentity) {
		this.partCategoryMappingIdentity = partCategoryMappingIdentity;
	}

	public void setUpdatedBy(long updatedBy) {
		this.updatedBy = updatedBy;
	}
   

	
}
