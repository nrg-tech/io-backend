package com.nissandigital.inventoryoptimization.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistence class for the io_mv_metrics database table.
 * 
 * @author Nissan Digital
 * 
 */
@Entity
@Table(name = "io_mv_metrics")
@NamedQuery(name = "StatisticalMVMetricsEntity.findAll", query = "SELECT i FROM StatisticalMVMetricsEntity i")
public class StatisticalMVMetricsEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "plant_id")
	@Id
	private Integer plantId;

	@Column(name = "curr_inv_bsl")
	private Double currentInventoryBaseline;

	@Column(name = "curr_inv_bsl_diff")
	private Double currentInventoryBaselineDifference;

	@Column(name = "curr_safety_stock")
	private Double currentSafetyStock;

	@Column(name = "curr_safety_stock_diff")
	private Double currentSafetyStockDifference;

	@Column(name = "stock_keeping_unit")
	private Integer stockKeepingUnit;

	@Column(name = "surpl_safety_stock")
	private Double surplusSafetyStock;

	@Column(name = "surpl_safety_stock_diff")
	private Double surplusSafetyStockDifference;

	@Column(name = "model_exec_dt")
	private Date modelExecutionDate;

	public StatisticalMVMetricsEntity() {
	}

	/**
	 * @return the modelExecutionDate
	 */
	public Date getModelExecutionDate() {
		return modelExecutionDate;
	}

	/**
	 * @param modelExecutionDate the modelExecutionDate to set
	 */
	public void setModelExecutionDate(Date modelExecutionDate) {
		this.modelExecutionDate = modelExecutionDate;
	}

	/**
	 * @return the plantId
	 */
	public Integer getPlantId() {
		return plantId;
	}

	/**
	 * @param plantId the plantId to set
	 */
	public void setPlantId(Integer id) {
		this.plantId = id;
	}

	/**
	 * @return the currentInventoryBaseline
	 */
	public Double getCurrentInventoryBaseline() {
		return currentInventoryBaseline;
	}

	/**
	 * @param currentInventoryBaseline the currentInventoryBaseline to set
	 */
	public void setCurrentInventoryBaseline(Double currInvBsl) {
		this.currentInventoryBaseline = currInvBsl;
	}

	/**
	 * @return the currentInventoryBaselineDifference
	 */
	public Double getCurrentInventoryBaselineDifference() {
		return currentInventoryBaselineDifference;
	}

	/**
	 * @param currentInventoryBaselineDifference the
	 *                                           currentInventoryBaselineDifference
	 *                                           to set
	 */
	public void setCurrentInventoryBaselineDifference(Double currInvBslDiff) {
		this.currentInventoryBaselineDifference = currInvBslDiff;
	}

	/**
	 * @return the currentSafetyStock
	 */
	public Double getCurrentSafetyStock() {
		return currentSafetyStock;
	}

	/**
	 * @param currentSafetyStock the currentSafetyStock to set
	 */
	public void setCurrentSafetyStock(Double currSafetyStock) {
		this.currentSafetyStock = currSafetyStock;
	}

	/**
	 * @return the currentSafetyStockDifference
	 */
	public Double getCurrentSafetyStockDifference() {
		return currentSafetyStockDifference;
	}

	/**
	 * @param currentSafetyStockDifference the currentSafetyStockDifference to set
	 */
	public void setCurrentSafetyStockDifference(Double currSafetyStockDiff) {
		this.currentSafetyStockDifference = currSafetyStockDiff;
	}

	/**
	 * @return the stockKeepingUnit
	 */
	public Integer getStockKeepingUnit() {
		return stockKeepingUnit;
	}

	/**
	 * @param stockKeepingUnit the stockKeepingUnit to set
	 */
	public void setStockKeepingUnit(Integer stockKeepingUnit) {
		this.stockKeepingUnit = stockKeepingUnit;
	}

	/**
	 * @return the surplusSafetyStock
	 */
	public Double getSurplusSafetyStock() {
		return surplusSafetyStock;
	}

	/**
	 * @param surplusSafetyStock the surplusSafetyStock to set
	 */
	public void setSurplusSafetyStock(Double surplSafetyStock) {
		this.surplusSafetyStock = surplSafetyStock;
	}

	/**
	 * @return the surplusSafetyStockDifference
	 */
	public Double getSurplusSafetyStockDifference() {
		return surplusSafetyStockDifference;
	}

	/**
	 * @param surplusSafetyStockDifference the surplusSafetyStockDifference to set
	 */
	public void setSurplusSafetyStockDifference(Double surplSafetyStockDiff) {
		this.surplusSafetyStockDifference = surplSafetyStockDiff;
	}

}
