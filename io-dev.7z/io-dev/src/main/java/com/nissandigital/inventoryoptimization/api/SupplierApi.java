package com.nissandigital.inventoryoptimization.api;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nissandigital.inventoryoptimization.dto.SupplierDTO;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;

@RequestMapping(value="suppliers")
public interface SupplierApi {
	
	@ApiOperation(value = "Fetch the information of all the suppliers", nickname = "getSuppliers", notes = "Returns the information of all the suppliers ", response = SupplierDTO.class, tags = {
	"supplier" })
	@ApiResponse(code = 200, message = "Supplier information successfully fetched", response = SupplierDTO.class)
	@GetMapping(produces = { "application/json" })
ResponseEntity<List<SupplierDTO>> getSuppliers();
}


