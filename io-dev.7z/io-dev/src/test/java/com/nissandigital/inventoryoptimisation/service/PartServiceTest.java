package com.nissandigital.inventoryoptimisation.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import javax.validation.ValidationException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import org.assertj.core.api.Assertions;
import static org.assertj.core.groups.Tuple.tuple;

import com.nissandigital.inventoryoptimization.exception.NoDataFoundException;
import com.nissandigital.inventoryoptimization.common.InventoryOptimizationUtils;
import com.nissandigital.inventoryoptimization.dto.PartDTO;
import com.nissandigital.inventoryoptimization.entity.PartEntity;
import com.nissandigital.inventoryoptimization.repository.PartRepository;
import com.nissandigital.inventoryoptimization.service.impl.PartServiceImpl;


/**
 * Test class for PartServiceTest
 * 
 * @author Nissan Digital
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class PartServiceTest {
   
   @Mock
   private PartRepository mockPartRepository;
   
   @InjectMocks
   private PartServiceImpl partService;
   
   
   PartDTO partDTO;
   
   @Before
   public void setup() throws Exception{
	   
		PartEntity part1 = new PartEntity();		
		part1.setPartId((long) 1);
		part1.setPlantId((long)1);
		part1.setItemNumber("92310810");
		part1.setItemDescription("PIN-SNAP ");
		part1.setPartClassCode('B');
		part1.setUnitPrice(0.120000);
		part1.setOperationalReserveQuantity(6563);
		part1.setMinRanOrderQuantity(120000);
		part1.setSnpQuantity(120000);
		part1.setFloatTypeUseCd('H');
		part1.setRecommendedDays(1200.00);
		part1.setRecommendedHours(120.00);
		part1.setFloatComments("PER KAREN");
		part1.setLoadDate(InventoryOptimizationUtils.getCurrentUTCTimestamp());
		
		
		
		
		PartEntity part2 = new PartEntity();
		part2.setPartId((long) 2);
		part2.setPlantId((long)1);
		part2.setItemNumber("112102051");
		part2.setItemDescription("BOLT-HEX,PPW/SPW & P");
		part2.setPartClassCode('B');
		part2.setUnitPrice(0.120000);
		part2.setOperationalReserveQuantity(6563);
		part2.setMinRanOrderQuantity(120000);
		part2.setSnpQuantity(120000);
		part2.setFloatTypeUseCd('H');
		part2.setRecommendedDays(1200.00);
		part2.setRecommendedHours(120.00);
		part2.setFloatComments("PER KAREN");
		part2.setLoadDate(InventoryOptimizationUtils.getCurrentUTCTimestamp());

		Optional<PartEntity> PartOptional = Optional.of(part1);
		Optional<PartEntity> PartOptionalEmpty = Optional.empty();

		List<PartEntity> Parts = new ArrayList<>();
		Parts.add(part1);
		Parts.add(part2);
		
		partDTO = new PartDTO();
		partDTO.setPartId(1);
		partDTO.setPlantId((long)1);
		partDTO.setItemNumber("92310810");
		partDTO.setItemDescription("PIN-SNAP ");
		partDTO.setPartClassCode('B');
		partDTO.setUnitPrice(0.304);
		partDTO.setOperationalReserveQuantity(120.0);
		partDTO.setMinRanOrderQuantity(120000);
		partDTO.setSnpQuantity(120000);
		partDTO.setFloatTypeUseCd('H');
		partDTO.setRecommendedDays(120.0);
		partDTO.setRecommendedHours(120.0);
		partDTO.setFloatComments("PER KAREN");
		partDTO.setLoadDate(InventoryOptimizationUtils.getCurrentUTCTimestamp());
		
		when(mockPartRepository.findById((long) 1)).thenReturn(PartOptional);
		when(mockPartRepository.findById((long) 2)).thenReturn(PartOptionalEmpty);
		when(mockPartRepository.findAll()).thenReturn(Parts);
		when(mockPartRepository.save(any(PartEntity.class))).thenReturn(part1);
		Mockito.doNothing().when(mockPartRepository)
         .delete(any(PartEntity.class));
   }
  
   @Test
	public void testFindPart() {
	   PartDTO PartDTO = partService.findPart(1);
	   assertEquals((int) 1, PartDTO.getPartId());
	}

   @Test(expected = NoDataFoundException.class)
  	public void testFindPartThrowsNoDataFoundException() {
  	   partService.findPart(2);
  	}
   
   
   @Test
	public void testFindAllParts() {
	   List<PartDTO> PartList = partService.findAllParts();
	   Assertions.assertThat(PartList)
       .extracting(PartDTO::getPartId,PartDTO :: getPlantId )
       .containsExactly(tuple(1, "CODE1"),
                        tuple(1, "CODE2"));
	}
	
  
   
	@Test
	public void testCreatePart() {
		assertEquals((int) 1, partService.createPart(partDTO));
	}
	
	@Test(expected = ValidationException.class)
	public void testCreatePartThrowsValidationException() {
		PartDTO PartDTOEmpty = new PartDTO();
		partService.createPart(PartDTOEmpty);
	}
	
	@Test
	public void testUpdatePart() {
		assertEquals((int) 1, partService.updatePart(partDTO));
	}
	
	
	
	@Test(expected = ValidationException.class)
	public void testUpdatePartThrowsValidationException() {
		PartDTO PartDTOOnlyId = new PartDTO();
		PartDTOOnlyId.setPartId(1);
		 partService.updatePart(PartDTOOnlyId);
	}
	
	
	@Test(expected = NoDataFoundException.class)
	public void testCreatePartThrowsNoDataFoundException() {
		PartDTO partDTOInvalidId = new PartDTO();
		partDTOInvalidId.setPartId(2);
		partService.updatePart(partDTOInvalidId);
	}

	
	@Test
	public void testDeletePart() {
		partService.deletePart(1);
	}
	
	@Test(expected = NoDataFoundException.class)
	public void testDeletePartThrowsNoDataFoundException() {
		 partService.deletePart(1);
	}


}
