package com.nissandigital.inventoryoptimisation.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.modelmapper.ModelMapper;
import org.springframework.test.util.ReflectionTestUtils;

import com.nissandigital.inventoryoptimization.dto.AggregateStatisticsDTO;
import com.nissandigital.inventoryoptimization.dto.UserDetailsDTO;
import com.nissandigital.inventoryoptimization.entity.StatisticalMVMetricsEntity;
import com.nissandigital.inventoryoptimization.repository.StatisticalMVMetricsRepository;
import com.nissandigital.inventoryoptimization.service.UserService;
import com.nissandigital.inventoryoptimization.service.impl.AggregateStatisticsServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class AggregateStatisticsServiceTest {

	@Mock
	UserService mockUserService;

	@Mock
	StatisticalMVMetricsRepository mockStatisticsRepository;

	@InjectMocks
	AggregateStatisticsServiceImpl mockAggregateStatistics;

	StatisticalMVMetricsEntity entity;

	@Before
	public void setup() throws Exception {
		entity = new StatisticalMVMetricsEntity();
		entity.setCurrentInventoryBaseline(9.12);
		entity.setCurrentInventoryBaselineDifference(0.21);
		entity.setCurrentSafetyStock(2154.00);
		entity.setCurrentSafetyStockDifference(2.3);
		entity.setModelExecutionDate(new Date());
		entity.setPlantId(1);
		entity.setStockKeepingUnit(21543);
		entity.setSurplusSafetyStock(112.00);
		entity.setSurplusSafetyStockDifference(1.65);

		UserDetailsDTO user = new UserDetailsDTO();
		user.setPlantId(1);
		user.setUserId(1001);

		ModelMapper modelMapper = new ModelMapper();
		modelMapper.getConfiguration().setSkipNullEnabled(true);
		ReflectionTestUtils.setField(mockAggregateStatistics, "modelMapper", modelMapper);

		when(mockUserService.getCurrentUser()).thenReturn(user);
		when(mockStatisticsRepository.findById(1)).thenReturn(Optional.of(entity));
	}

	@Test
	public void testGetAggregateStatistics() {
		AggregateStatisticsDTO response = mockAggregateStatistics.getAggregateStatistics();
		assertEquals(entity.getCurrentInventoryBaseline(), response.getCurrentInventoryBaseline());
		assertEquals(entity.getCurrentInventoryBaselineDifference(), response.getCurrentInventoryBaselineDifference());
		assertEquals(entity.getCurrentSafetyStock(), response.getCurrentSafetyStock());
		assertEquals(entity.getCurrentSafetyStockDifference(), response.getCurrentSafetyStockDifference());
		assertEquals(entity.getModelExecutionDate(),response.getModelExecutionDate());
		assertEquals(entity.getPlantId(), response.getPlantId());
		assertEquals(entity.getStockKeepingUnit(), response.getStockKeepingUnit());
		assertEquals(entity.getSurplusSafetyStock(), response.getSurplusSafetyStock());
		assertEquals(entity.getSurplusSafetyStockDifference(), response.getSurplusSafetyStockDifference());
	}

}
