package com.nissandigital.inventoryoptimisation.common;

import static org.hamcrest.core.IsInstanceOf.instanceOf;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import com.nissandigital.inventoryoptimization.common.InventoryOptimizationUtils;
import com.nissandigital.inventoryoptimization.dto.Status;
import com.nissandigital.inventoryoptimization.exception.NoDataFoundException;

/**
 * Test class for InventoryOptimisationUtils
 * 
 * @author Nissan Digital
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class InventoryOptimizationUtilsTest {
	@Test
	public void testSetMessage() {
		String message = "Test Status";
		Status status = InventoryOptimizationUtils.setMessage(message);
		assertEquals(message, status.getMessage());
	}
	
	@Test
	public void testGetCurrentUTCTimestamp() {
		assertThat(InventoryOptimizationUtils.getCurrentUTCTimestamp(), instanceOf(Timestamp.class));

	}
	
}
